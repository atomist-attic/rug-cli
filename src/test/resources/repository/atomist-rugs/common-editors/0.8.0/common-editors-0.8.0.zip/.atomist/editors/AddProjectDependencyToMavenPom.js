var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var AddProjectDependencyToMavenPom = (function () {
    function AddProjectDependencyToMavenPom() {
    }
    AddProjectDependencyToMavenPom.prototype.edit = function (project) {
        var _this = this;
        var eng = project.context().pathExpressionEngine();
        eng.with(project, '//Pom()', function (p) {
            p.addOrReplaceDependencyOfVersion(_this.group_id, _this.artifact_id, _this.version);
        });
    };
    return AddProjectDependencyToMavenPom;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Group ID",
        description: "Group identifier used by Maven",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "A valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters."
    }),
    __metadata("design:type", String)
], AddProjectDependencyToMavenPom.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Artifact ID",
        description: "Artifact identifier used by Maven",
        pattern: "^[a-z][-a-z0-9_\.]*$",
        validInput: "A valid Maven artifact ID, which starts with a lower-case letter and contains only alphanumeric, -, and _ characters"
    }),
    __metadata("design:type", String)
], AddProjectDependencyToMavenPom.prototype, "artifact_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Version",
        description: "Current version of the project",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "A valid semantic version, http://semver.org"
    }),
    __metadata("design:type", String)
], AddProjectDependencyToMavenPom.prototype, "version", void 0);
AddProjectDependencyToMavenPom = __decorate([
    Decorators_1.Editor("AddProjectDependencyToMavenPom", "adds a project dependency to an existing Maven pom.xml"),
    Decorators_1.Tags("maven")
], AddProjectDependencyToMavenPom);
exports.editor_addProjectDependencyToMavenPom = new AddProjectDependencyToMavenPom();
//# sourceMappingURL=AddProjectDependencyToMavenPom.js.map