var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var AddApacheSoftwareLicense20 = (function () {
    function AddApacheSoftwareLicense20() {
    }
    AddApacheSoftwareLicense20.prototype.edit = function (project) {
        var eng = project.context.pathExpressionEngine;
        var license = "ApacheSoftwareLicenseV20";
        var licenseFilename = "LICENSE";
        var p = project;
        p.copyEditorBackingFilesOrFail(license, licenseFilename);
    };
    return AddApacheSoftwareLicense20;
}());
AddApacheSoftwareLicense20 = __decorate([
    Decorators_1.Editor("AddApacheSoftwareLicense20", "add the Apache Software License version 2.0 file"),
    Decorators_1.Tags("apache", "license", "documentation")
], AddApacheSoftwareLicense20);
exports.editor_addApacheSoftwareLicense20 = new AddApacheSoftwareLicense20();
//# sourceMappingURL=AddApacheSoftwareLicense20.js.map