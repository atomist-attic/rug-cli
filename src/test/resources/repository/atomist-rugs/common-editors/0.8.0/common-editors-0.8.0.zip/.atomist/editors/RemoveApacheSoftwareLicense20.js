var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RemoveApacheSoftwareLicense20 = (function () {
    function RemoveApacheSoftwareLicense20() {
    }
    RemoveApacheSoftwareLicense20.prototype.edit = function (project) {
        var licenseFilename = "LICENSE";
        var p = project;
        if (p.fileExists(licenseFilename) && p.fileContains(licenseFilename, "Version 2.0")) {
            p.deleteFile(licenseFilename);
        }
    };
    return RemoveApacheSoftwareLicense20;
}());
RemoveApacheSoftwareLicense20 = __decorate([
    Decorators_1.Editor("RemoveApacheSoftwareLicense20", "removes an Apache Software License version 2.0 file if present"),
    Decorators_1.Tags("apache", "license", "documentation")
], RemoveApacheSoftwareLicense20);
exports.editor_removeApacheSoftwareLicense20 = new RemoveApacheSoftwareLicense20();
//# sourceMappingURL=RemoveApacheSoftwareLicense20.js.map