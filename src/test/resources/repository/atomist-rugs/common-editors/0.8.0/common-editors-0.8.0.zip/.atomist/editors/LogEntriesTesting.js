Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var LogEntriesTesting = (function () {
    function LogEntriesTesting() {
        this.tags = ["log", "entries"];
        this.name = "LogEntriesTesting";
        this.description = "Test log entries";
    }
    LogEntriesTesting.prototype.edit = function (project) {
        var p = project;
        p.addFile("src/main/whitespace", "      \t\n    \t");
        p.describeChange("Added valid program in Whitespace(tm) programming language");
        return new RugOperation_1.Result(RugOperation_1.Status.Success, "Update Travis Maven build files");
    };
    return LogEntriesTesting;
}());
exports.entries = new LogEntriesTesting();
//# sourceMappingURL=LogEntriesTesting.js.map