var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var AddChangeLog = (function () {
    function AddChangeLog() {
    }
    AddChangeLog.prototype.edit = function (project) {
        var _this = this;
        var eng = project.context.pathExpressionEngine;
        var changelogTemplate = "empty-changelog.md";
        var changelog = "CHANGELOG.md";
        var p = project;
        p.copyEditorBackingFilesOrFail(changelogTemplate, changelog);
        eng.with(p, "//File()[@name='" + changelog + "']", function (f) {
            f.replace("{{repo_slug}}", _this.repo_slug);
        });
    };
    return AddChangeLog;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Repo Slug",
        description: "GitHub repository slug of the form 'owner/name'",
        pattern: "^[-\\w.]+/[-\\w.]+$",
        validInput: "An existing Github repository slug of the form 'owner/repo', must be 3-100 characters long",
        minLength: 3,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddChangeLog.prototype, "repo_slug", void 0);
AddChangeLog = __decorate([
    Decorators_1.Editor("AddChangeLog", "adds a new CHANGELOG"),
    Decorators_1.Tags("changelog", "documentation")
], AddChangeLog);
exports.editor_addChangeLog = new AddChangeLog();
//# sourceMappingURL=AddChangeLog.js.map