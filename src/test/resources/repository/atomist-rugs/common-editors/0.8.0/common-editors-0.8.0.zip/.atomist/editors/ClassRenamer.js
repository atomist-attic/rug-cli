var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var ClassRenamer = (function () {
    function ClassRenamer() {
    }
    ClassRenamer.prototype.edit = function (project) {
        var _this = this;
        var eng = project.context.pathExpressionEngine;
        eng.with(project, '//JavaType()', function (c) {
            if (c.name.indexOf(_this.old_class) >= 0) {
                c.renameByReplace(_this.old_class, _this.new_class);
            }
        });
        var p = project;
        p.replace(this.old_class, this.new_class);
    };
    return ClassRenamer;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Current Class Name",
        description: "Name of Java class to rename",
        pattern: RugOperation_1.Pattern.java_identifier,
        validInput: "A valid Java class name, which contains only alphanumeric characters, $ and _ and does not start with a number"
    }),
    __metadata("design:type", String)
], ClassRenamer.prototype, "old_class", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "New Class Name",
        description: "New name for the Java class",
        pattern: RugOperation_1.Pattern.java_identifier,
        validInput: "A valid Java class name, which contains only alphanumeric characters, $ and _ and does not start with a number"
    }),
    __metadata("design:type", String)
], ClassRenamer.prototype, "new_class", void 0);
ClassRenamer = __decorate([
    Decorators_1.Editor("ClassRenamer", "renames a Java class, replacing one literal pattern with another"),
    Decorators_1.Tags("java")
], ClassRenamer);
exports.editor_classRenamer = new ClassRenamer();
//# sourceMappingURL=ClassRenamer.js.map