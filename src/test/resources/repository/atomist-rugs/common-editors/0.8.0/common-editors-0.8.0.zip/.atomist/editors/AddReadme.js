var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var AddReadme = (function () {
    function AddReadme() {
    }
    AddReadme.prototype.edit = function (project) {
        var eng = project.context.pathExpressionEngine;
        var readme = "readme.vm";
        var readmeFilename = "README.md";
        var p = project;
        p.merge(readme, readmeFilename, { project_name: this.project_name, description: this.description });
    };
    return AddReadme;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Name",
        description: "Name of the project",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "A valid GitHub project name using only letters, digits, hyphens",
        minLength: 1
    }),
    __metadata("design:type", String)
], AddReadme.prototype, "project_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Description",
        description: "One-sentence description of the project",
        pattern: "^.*$",
        validInput: "A string 1-90 characters long",
        minLength: 1,
        maxLength: 90
    }),
    __metadata("design:type", String)
], AddReadme.prototype, "description", void 0);
AddReadme = __decorate([
    Decorators_1.Editor("AddReadme", "adds a project specific README"),
    Decorators_1.Tags("readme", "documentation")
], AddReadme);
exports.editor_addReadme = new AddReadme();
//# sourceMappingURL=AddReadme.js.map