var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var PackageMove = (function () {
    function PackageMove() {
    }
    PackageMove.prototype.edit = function (project) {
        var _this = this;
        var eng = project.context.pathExpressionEngine;
        eng.with(project, '//JavaSource()', function (j) {
            if (j.pkg() == _this.old_package) {
                j.movePackage(_this.new_package);
            }
        });
    };
    return PackageMove;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Current Package Name",
        description: "Name of Java package to rename",
        pattern: RugOperation_1.Pattern.java_package,
        validInput: "A valid Java package name, which consists of period-separated identifiers which have only alphanumeric characters, $ and _ and do not start with a number"
    }),
    __metadata("design:type", String)
], PackageMove.prototype, "old_package", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "New Package Name",
        description: "New name for the Java package",
        pattern: RugOperation_1.Pattern.java_package,
        validInput: "A valid Java package name, which consists of period-separated identifiers which have only alphanumeric characters, $ and _ and do not start with a number"
    }),
    __metadata("design:type", String)
], PackageMove.prototype, "new_package", void 0);
PackageMove = __decorate([
    Decorators_1.Editor("PackageMove", "renames a Java package"),
    Decorators_1.Tags("java")
], PackageMove);
exports.editor_packageMove = new PackageMove();
//# sourceMappingURL=PackageMove.js.map