var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var PomParameterizer = (function () {
    function PomParameterizer() {
        this.version = "0.1.0";
    }
    PomParameterizer.prototype.edit = function (project) {
        var _this = this;
        var eng = project.context.pathExpressionEngine;
        eng.with(project, '//Pom()', function (p) {
            if (p.path == "pom.xml") {
                p.setArtifactId(_this.artifact_id);
                p.setGroupId(_this.group_id);
                p.setVersion(_this.version);
                p.setProjectName(_this.name);
                p.setDescription(_this.description);
            }
        });
    };
    return PomParameterizer;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Artifact ID",
        description: "Artifact identifier used by Maven",
        pattern: "^[a-z][-a-z0-9_]*$",
        validInput: "A valid Maven artifact ID, which starts with a lower-case letter and contains only alphanumeric, -, and _ characters"
    }),
    __metadata("design:type", String)
], PomParameterizer.prototype, "artifact_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Group ID",
        description: "Group identifier used by Maven",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "A valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters."
    }),
    __metadata("design:type", String)
], PomParameterizer.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        description: "Name of the project",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "Any valid Maven project name as per: https://maven.apache.org/guides/introduction/introduction-to-the-pom.html",
        minLength: 1
    }),
    __metadata("design:type", String)
], PomParameterizer.prototype, "name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Version",
        description: "Current version of the project",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "A valid semantic version, http://semver.org"
    }),
    __metadata("design:type", String)
], PomParameterizer.prototype, "version", void 0);
__decorate([
    Decorators_1.Parameter({
        description: "Description of your new project",
        pattern: "^.*$"
    }),
    __metadata("design:type", String)
], PomParameterizer.prototype, "description", void 0);
PomParameterizer = __decorate([
    Decorators_1.Editor("PomParameterizer", "updates a Maven pom to a new group, artifact, version and description"),
    Decorators_1.Tags("java", "apache", "maven")
], PomParameterizer);
exports.editor_pomParameterizer = new PomParameterizer();
//# sourceMappingURL=PomParameterizer.js.map