var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugGeneratorFunctions_1 = require("./RugGeneratorFunctions");
var NewStarterRugProject = (function () {
    function NewStarterRugProject() {
    }
    NewStarterRugProject.prototype.populate = function (project) {
        RugGeneratorFunctions_1.removeUnnecessaryFiles(project);
        var description = "Atomist Rug archive project.";
        var owner = "atomist-rugs";
        RugGeneratorFunctions_1.cleanReadMe(project, this.project_name, description, owner);
        RugGeneratorFunctions_1.cleanChangeLog(project, this.project_name, owner);
        var version = "0.1.0";
        var manifestParams = {
            archive_name: this.project_name,
            group_id: owner,
            version: version
        };
        project.editWith("AddManifestYml", manifestParams);
        project.editWith("AddTypeScript", {});
        var editorParams = {
            editor_name: "MyFirstEditor",
            description: "A sample Rug TypeScript editor to start playing with."
        };
        project.editWith("AddTypeScriptEditor", editorParams);
    };
    return NewStarterRugProject;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Name",
        description: "name of project to be created",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "a valid GitHub project name consisting of alphanumeric, ., -, and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], NewStarterRugProject.prototype, "project_name", void 0);
NewStarterRugProject = __decorate([
    Decorators_1.Generator("NewStarterRugProject", "create new Rug archive project using standard setup and sensible defaults"),
    Decorators_1.Tags("atomist", "rug", "documentation", "starter")
], NewStarterRugProject);
exports.newStarterRugProject = new NewStarterRugProject();
//# sourceMappingURL=NewStarterRugProject.js.map