var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
function removeUnnecessaryFiles(project, extra) {
    var toRemove = [
        ".atomist.yml",
        ".travis.yml"
    ];
    if (extra != null) {
        toRemove = toRemove.concat(extra);
    }
    for (var _i = 0, toRemove_1 = toRemove; _i < toRemove_1.length; _i++) {
        var f = toRemove_1[_i];
        project.deleteFile(f);
    }
}
exports.removeUnnecessaryFiles = removeUnnecessaryFiles;
function cleanReadMe(project, projectName, description, owner) {
    var eng = project.context().pathExpressionEngine();
    var readMePE = new PathExpression_1.PathExpression("/*[@name='README.md']");
    var readMe = eng.scalar(project, readMePE);
    readMe.replace("# Atomist 'rug-project'", "# " + projectName);
    readMe.regexpReplace("a Rug archive project generator.[\\s\\S]*?\n## Rugs\n", description + "\n\n## Rugs\n");
    readMe.regexpReplace("\n### NewRugProject[\\s\\S]*\n## Support\n", "\n## Support\n");
    readMe.replace("rug-project", projectName);
    readMe.replace("atomist-rugs", owner);
}
exports.cleanReadMe = cleanReadMe;
function cleanChangeLog(project, projectName, owner) {
    var eng = project.context().pathExpressionEngine();
    var changeLogPE = new PathExpression_1.PathExpression("/*[@name='CHANGELOG.md']");
    var changeLog = eng.scalar(project, changeLogPE);
    changeLog.regexpReplace("\\d+\\.\\d+\\.\\d+\\.\\.\\.HEAD\n\n[\\S\\s]*## \\[0\\.1\\.0\\]", "0.1.0...HEAD\n\n## [0.1.0]");
    changeLog.regexpReplace("\n### Added[\\S\\s]*", "\nAdded\n\n-   Everything\n");
    changeLog.replace("rug-project", projectName);
    changeLog.replace("atomist-rugs", owner);
}
exports.cleanChangeLog = cleanChangeLog;
//# sourceMappingURL=RugGeneratorFunctions.js.map