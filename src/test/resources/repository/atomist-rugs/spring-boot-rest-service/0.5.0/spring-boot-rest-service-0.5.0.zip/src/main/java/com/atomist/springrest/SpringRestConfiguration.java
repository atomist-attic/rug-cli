package com.atomist.springrest;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringRestConfiguration {

    // Your beans go here ...
	  // Atomist Bot suggests "maybe use an Atomist project editor to add a sample one?"
}
