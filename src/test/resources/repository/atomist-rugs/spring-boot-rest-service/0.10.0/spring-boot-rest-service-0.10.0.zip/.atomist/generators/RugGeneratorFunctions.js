Object.defineProperty(exports, "__esModule", { value: true });
function cleanReadMe(project, description, owner) {
    var readMe = project.findFile("README.md");
    readMe.replace("# Atomist 'spring-boot-rest-service'", "# " + project.name);
    readMe.regexpReplace("This .*?Rug.*? project contains a generator for a .*?Spring Boot[\\s\\S]*?\n## Spring Boot REST Service\n", "This project contains a [Spring Boot][boot] [REST][rest] service for " + description + ".");
    readMe.replace("spring-boot-rest-service", project.name);
    readMe.replace("atomist-rugs", owner);
}
exports.cleanReadMe = cleanReadMe;
function cleanChangeLog(project, owner) {
    var changeLog = project.findFile("CHANGELOG.md");
    changeLog.regexpReplace("\\d+\\.\\d+\\.\\d+\\.\\.\\.HEAD\n\n[\\S\\s]*## \\[0\\.1\\.0\\]", "0.1.0...HEAD\n\n## [0.1.0]");
    changeLog.regexpReplace("\n### Added[\\S\\s]*", "\nAdded\n\n-   Everything\n");
    changeLog.replace("spring-boot-rest-service", project.name);
    changeLog.replace("atomist-rugs", owner);
}
exports.cleanChangeLog = cleanChangeLog;
function removeUnnecessaryFiles(project) {
    var toDelete = ["LICENSE", "CODE_OF_CONDUCT.md", ".travis.yml"];
    for (var _i = 0, toDelete_1 = toDelete; _i < toDelete_1.length; _i++) {
        var f = toDelete_1[_i];
        project.deleteFile(f);
    }
}
exports.removeUnnecessaryFiles = removeUnnecessaryFiles;
function updatePom(project, artifactId, groupId, version, description) {
    var eng = project.context.pathExpressionEngine;
    eng.with(project, "/Pom()", function (pom) {
        pom.setArtifactId(artifactId);
        pom.setGroupId(groupId);
        pom.setProjectName(project.name);
        pom.setVersion(version);
        pom.setDescription(description);
    });
}
exports.updatePom = updatePom;
function movePackage(project, oldPackage, newPackage) {
    var eng = project.context.pathExpressionEngine;
    eng.with(project, "//JavaSource()[.pkg()='" + oldPackage + "']", function (j) {
        j.movePackage(newPackage);
    });
}
exports.movePackage = movePackage;
function renameClass(project, oldClass, newClass) {
    var eng = project.context.pathExpressionEngine;
    eng.with(project, "//JavaType()", function (j) {
        if (j.name.indexOf(oldClass) >= 0) {
            j.renameByReplace(oldClass, newClass);
        }
    });
    project.replace(oldClass, newClass);
}
exports.renameClass = renameClass;
//# sourceMappingURL=RugGeneratorFunctions.js.map