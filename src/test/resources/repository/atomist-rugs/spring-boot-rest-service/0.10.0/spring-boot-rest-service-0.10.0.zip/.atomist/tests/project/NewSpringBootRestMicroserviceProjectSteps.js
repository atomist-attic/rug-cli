Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var projectName = "MyService";
var artifactId = "foo";
var rootPackage = "com.foo.bar";
var version = "0.0.1";
var serviceClassName = "MyTest";
var propsFile = "src/main/resources/application.properties";
var groupId = "somegroup";
var pomPath = "pom.xml";
var readmePath = "README.md";
var description = "And now for something completely different";
var srcPath = "src/main/java/com/foo/bar/" + serviceClassName + "Application.java";
var testPath = "src/test/java/com/foo/bar/" + serviceClassName + "ApplicationTests.java";
Core_1.When("NewSpringBootRestService is provided all parameters", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewSpringBootRestService");
    psworld.generateWith(generator, projectName, {
        artifactId: artifactId,
        rootPackage: rootPackage,
        version: version,
        serviceClassName: serviceClassName,
        groupId: groupId,
        description: description
    });
});
Core_1.Then("the class source file exists", function (p, world) {
    return p.fileExists(srcPath);
});
Core_1.Then("the class source file contains the class name", function (p, world) {
    return p.fileContains(srcPath, "public class " + serviceClassName + "Application ");
});
Core_1.Then("the class source file contains the package name", function (p, world) {
    return p.fileContains(srcPath, "package " + rootPackage);
});
Core_1.Then("the class source file should not contain the original class name", function (p, world) {
    return !p.fileContains(srcPath, "SpringRestApplication");
});
Core_1.Then("the class source file should not contain the original package name", function (p, world) {
    return !p.fileContains(srcPath, "com.atomist.springrest");
});
Core_1.Then("the class test file exists", function (p, world) {
    return p.fileExists(testPath);
});
Core_1.Then("the class test file contains the class name", function (p, world) {
    return p.fileContains(testPath, "public class " + serviceClassName + "ApplicationTests ");
});
Core_1.Then("the class test file contains the package name", function (p, world) {
    return p.fileContains(testPath, "package " + rootPackage);
});
Core_1.Then("the class test file should not contain the original class name", function (p, world) {
    return !p.fileContains(testPath, "SpringRestApplicationTests");
});
Core_1.Then("the class test file should not contain the original package name", function (p, world) {
    return !p.fileContains(testPath, "com.atomist.springrest");
});
Core_1.Then("the class test file exists", function (p, world) {
    return p.fileExists(testPath);
});
Core_1.Then("the POM file contains the artifact ID", function (p, world) {
    return p.fileContains(pomPath, artifactId);
});
Core_1.Then("the POM file contains the version", function (p, world) {
    return p.fileContains(pomPath, version);
});
Core_1.Then("the README contains the project name", function (p, world) {
    return p.fileContains(readmePath, projectName);
});
Core_1.Then("the README contains the description", function (p, world) {
    return p.fileContains(readmePath, description);
});
Core_1.Then("the README contains help", function (p, world) {
    return p.fileContains(readmePath, "Need Help?");
});
Core_1.Then("the README contains Spring Boot", function (p, world) {
    return p.fileContains(readmePath, "[Spring Boot]");
});
Core_1.Then("the README contains Maven link", function (p, world) {
    return p.fileContains(readmePath, "[Maven][mvn]");
});
Core_1.Then("the README contains Maven instructions", function (p, world) {
    return p.fileContains(readmePath, "mvn spring-boot:run");
});
Core_1.Then("the README should not contain Rug information", function (p, world) {
    return !p.fileContains(readmePath, "## Rug");
});
Core_1.Then("the props file should exist", function (p, world) {
    return p.fileExists(propsFile);
});
Core_1.Then("the props file contains the server port", function (p, world) {
    return p.fileContains(propsFile, "server.port=8080");
});
Core_1.Then("the LICENSE file should not exist", function (p, world) {
    return !p.fileExists("LICENSE");
});
Core_1.Then("the CHANGELOG file should exist", function (p, world) {
    return p.fileExists("CHANGELOG.md");
});
Core_1.Then("the CHANGELOG file should not contain releases from this project", function (p, world) {
    return !p.fileContains("CHANGELOG.md", "0.3.0");
});
Core_1.Then("the code of conduct file should not exist", function (p, world) {
    return !p.fileExists("CODE_OF_CONDUCT.md");
});
Core_1.Then("the Travis CI configuration should not exist", function (p, world) {
    return !p.fileExists(".travis.yml");
});
Core_1.When("NewSpringBootRestService is provided all parameters but description", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewSpringBootRestService");
    psworld.generateWith(generator, projectName, {
        artifactId: artifactId,
        rootPackage: rootPackage,
        version: version,
        serviceClassName: serviceClassName,
        groupId: groupId
    });
});
Core_1.When("NewSpringBootRestService for NewSpringBootRestService should fail when given an invalid parameter", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewSpringBootRestService");
    var badVersion = "not.valid.version";
    psworld.generateWith(generator, projectName, {
        artifactId: artifactId,
        rootPackage: rootPackage,
        version: badVersion,
        serviceClassName: serviceClassName,
        groupId: groupId,
        description: description
    });
});
//# sourceMappingURL=NewSpringBootRestMicroserviceProjectSteps.js.map