"use strict";
var Core_1 = require("@atomist/rug/test/Core");
Core_1.When("run Spring Rest generator", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewSpringBootRestService");
    psworld.generateWith(generator, {});
});
Core_1.Then("we have a POM", function (p) { return p.fileExists("pom.xml"); });
Core_1.Then("we don't have a CODE_OF_CONDUCT", function (p) { return p.fileExists("CODE_OF_CONDUCT.md"); });
