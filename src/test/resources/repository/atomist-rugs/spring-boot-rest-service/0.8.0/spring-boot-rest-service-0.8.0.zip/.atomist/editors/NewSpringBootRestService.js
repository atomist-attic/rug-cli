"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugGeneratorFunctions_1 = require("./RugGeneratorFunctions");
var NewSpringBootRestService = (function () {
    function NewSpringBootRestService() {
        this.artifact_id = "myartifact";
        this.group_id = "mygroup";
        this.version = "0.1.0-SNAPSHOT";
        this.description = "My new project";
        this.root_package = "com.myorg";
        this.service_class_name = "My";
    }
    NewSpringBootRestService.prototype.populate = function (project) {
        RugGeneratorFunctions_1.cleanReadMe(project, project.name(), this.description, this.group_id);
        RugGeneratorFunctions_1.cleanChangeLog(project, project.name(), this.group_id);
        var pomParameterizerParams = {
            "artifact_id": this.artifact_id,
            "group_id": this.group_id,
            "version": this.version,
            "name": project.name(),
            "description": this.description
        };
        project.editWith("atomist-rugs:common-editors:PomParameterizer", pomParameterizerParams);
        var packageMoveParams = {
            "old_package": "com.atomist.springrest",
            "new_package": this.root_package
        };
        project.editWith("atomist-rugs:common-editors:PackageMove", packageMoveParams);
        var renameServiceClassParams = {
            "old_class": "SpringRest",
            "new_class": this.service_class_name
        };
        project.editWith("atomist-rugs:common-editors:ClassRenamer", renameServiceClassParams);
        RugGeneratorFunctions_1.removeUnnecessaryFiles(project);
    };
    return NewSpringBootRestService;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Maven Artifact ID",
        description: "Maven artifact identifier, i.e., the name of the jar without the version, it is often the same as the project name",
        pattern: "^[a-z][-a-z0-9_]*$",
        validInput: "a valid Maven artifact ID, which starts with a lower-case letter and contains only alphanumeric, -, and _ characters",
        minLength: 1,
        maxLength: 21,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "artifact_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Group ID",
        description: "Maven group identifier, often used to provide a namespace for your project, e.g., com.pany.team",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "a valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters.",
        minLength: 1,
        maxLength: 21,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Version",
        description: "initial version of the project, e.g., 1.2.3-SNAPSHOT",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "a valid semantic version, http://semver.org",
        minLength: 1,
        maxLength: 50,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "version", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Description",
        description: "short descriptive text describing the new project",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Root Package",
        description: "root package for your generated source, often this will be namespaced under the group ID",
        pattern: RugOperation_1.Pattern.java_package,
        validInput: "a valid Java package name, which consists of period-separated identifiers which have only alphanumeric characters, $ and _ and do not start with a number",
        minLength: 1,
        maxLength: 50,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "root_package", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Class Name",
        description: "name for the service class",
        pattern: RugOperation_1.Pattern.java_class,
        validInput: "a valid Java class name, which contains only alphanumeric characters, $ and _ and does not start with a number",
        minLength: 1,
        maxLength: 50,
        required: false
    }),
    __metadata("design:type", String)
], NewSpringBootRestService.prototype, "service_class_name", void 0);
NewSpringBootRestService = __decorate([
    Decorators_1.Generator("NewSpringBootRestService", "create a new Spring Boot Rest Service project"),
    Decorators_1.Tags("java", "spring", "spring-boot", "spring-rest"),
    __metadata("design:paramtypes", [])
], NewSpringBootRestService);
exports.newSpringBootRestService = new NewSpringBootRestService();
