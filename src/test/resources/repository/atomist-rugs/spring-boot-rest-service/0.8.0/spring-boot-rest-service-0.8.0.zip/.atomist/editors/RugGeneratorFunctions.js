"use strict";
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
function cleanReadMe(project, projectName, description, owner) {
    var eng = project.context().pathExpressionEngine();
    var readMePE = new PathExpression_1.PathExpression("/*[@name='README.md']");
    var readMe = eng.scalar(project, readMePE);
    readMe.replace("# Atomist 'spring-boot-rest-service'", "# " + projectName);
    readMe.regexpReplace("This .*?Rug.*? project contains a generator for a .*?Spring Boot[\\s\\S]*?\n## Support\n", description + "\n\n## Support\n");
    readMe.replace("spring-boot-rest-service", projectName);
    readMe.replace("atomist-rugs", owner);
}
exports.cleanReadMe = cleanReadMe;
function cleanChangeLog(project, projectName, owner) {
    var eng = project.context().pathExpressionEngine();
    var changeLogPE = new PathExpression_1.PathExpression("/*[@name='CHANGELOG.md']");
    var changeLog = eng.scalar(project, changeLogPE);
    changeLog.regexpReplace("\\d+\\.\\d+\\.\\d+\\.\\.\\.HEAD\n\n[\\S\\s]*## \\[0\\.1\\.0\\]", "0.1.0...HEAD\n\n## [0.1.0]");
    changeLog.regexpReplace("\n### Added[\\S\\s]*", "\nAdded\n\n-   Everything\n");
    changeLog.replace("spring-boot-rest-service", projectName);
    changeLog.replace("atomist-rugs", owner);
}
exports.cleanChangeLog = cleanChangeLog;
function removeUnnecessaryFiles(project) {
    project.editWith("atomist-rugs:common-editors:RemoveApacheSoftwareLicense20", {});
    project.editWith("atomist-rugs:common-editors:RemoveCodeOfConduct", {});
}
exports.removeUnnecessaryFiles = removeUnnecessaryFiles;
