"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("AddManifestYml for AddManifestYml should add the Rug manifest", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddManifestYml");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1", manifest: ".atomist/manifest.yml" });
});
Core_1.Then("fileExists manifest for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileExists(manifest);
});
Core_1.Then("fileContains manifest artifact archiveName for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'artifact: "' + archiveName + '"');
});
Core_1.Then("fileContains manifest group groupId for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'group: "' + groupId + '"');
});
Core_1.Then("fileContains manifest version for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, version);
});
Core_1.Then("not result fileContains manifest rug editors for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "rug-editors");
    ;
});
Core_1.Then("not result fileContains manifest atomist rugs for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "atomist-rugs");
    ;
});
Core_1.Then("not result fileContains manifest repo for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "repo:");
    ;
});
Core_1.Then("not result fileContains manifest branch for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "branch:");
    ;
});
Core_1.Then("not result fileContains manifest sha for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "sha:");
    ;
});
Core_1.Then("not result fileContains manifest for AddManifestYml should add the Rug manifest", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return !p.fileContains(manifest, "---");
    ;
});
Core_1.When("AddManifestYml for AddManifestYml should add the Rug manifest using default version", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddManifestYml");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var manifest = ".atomist/manifest.yml";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", manifest: ".atomist/manifest.yml" });
});
Core_1.Then("fileExists manifest for AddManifestYml should add the Rug manifest using default version", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var manifest = ".atomist/manifest.yml";
    return p.fileExists(manifest);
});
Core_1.Then("fileContains manifest artifact archiveName for AddManifestYml should add the Rug manifest using default version", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'artifact: "' + archiveName + '"');
});
Core_1.Then("fileContains manifest group groupId for AddManifestYml should add the Rug manifest using default version", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'group: "' + groupId + '"');
});
Core_1.Then("fileContains manifest 0 1 0 for AddManifestYml should add the Rug manifest using default version", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, "0.1.0");
});
Core_1.When("AddManifestYml archiveName is my-rug-archive for AddManifestYml should fail if parameters are missing", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddManifestYml");
    psworld.editWith(editor, { archiveName: "my-rug-archive" });
});
Core_1.When("AddManifestYml archiveName is my-rug-archive, groupId is my-rug-group, version is 0.0.1 for AddManifestYml should make no change if project already contains a manifest", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddManifestYml");
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1" });
});
