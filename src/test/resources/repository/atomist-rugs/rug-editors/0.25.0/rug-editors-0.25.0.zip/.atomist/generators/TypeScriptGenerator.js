"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var TypeScriptGenerator = (function () {
    function TypeScriptGenerator() {
        this.inputParameter = "input";
    }
    TypeScriptGenerator.prototype.populate = function (project) {
        console.log("Creating " + project.name + " with parameter " + this.inputParameter);
    };
    return TypeScriptGenerator;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Some Input",
        description: "example of how to specify a parameter using decorators",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a description of the valid input",
        minLength: 1,
        maxLength: 100,
        required: false
    }),
    __metadata("design:type", String)
], TypeScriptGenerator.prototype, "inputParameter", void 0);
TypeScriptGenerator = __decorate([
    Decorators_1.Generator("TypeScriptGenerator", "sample TypeScript generator used by AddTypeScriptGenerator"),
    Decorators_1.Tags("documentation")
], TypeScriptGenerator);
exports.TypeScriptGenerator = TypeScriptGenerator;
exports.typeScriptGenerator = new TypeScriptGenerator();
