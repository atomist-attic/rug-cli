"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var RugParameters_1 = require("./RugParameters");
var AddTypeScriptEventHandler = (function () {
    function AddTypeScriptEventHandler() {
        this.pathExpression = "/Tag()";
    }
    AddTypeScriptEventHandler.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            console.log("This project does not appear to be a Rug archive project");
            return;
        }
        project.editWith("AddTypeScript", {});
        var srcHandlerName = "TypeScriptEventHandler";
        var srcHandlerPath = ".atomist/handlers/event/" + srcHandlerName + ".ts";
        var srcTestPath = ".atomist/tests/handlers/event/" + srcHandlerName + "Steps.ts";
        var srcFeaturePath = ".atomist/tests/handlers/event/" + srcHandlerName + "Test.feature";
        var handlerPath = srcHandlerPath.replace(srcHandlerName, this.handlerName);
        var testPath = srcTestPath.replace(srcHandlerName, this.handlerName);
        var featurePath = srcFeaturePath.replace(srcHandlerName, this.handlerName);
        project.copyEditorBackingFileOrFailToDestination(srcHandlerPath, handlerPath);
        project.copyEditorBackingFileOrFailToDestination(srcTestPath, testPath);
        project.copyEditorBackingFileOrFailToDestination(srcFeaturePath, featurePath);
        var srcDescription = "sample TypeScript event handler used by AddTypeScriptEventHandler";
        var srcPathExpression = "/Tag()";
        var srcHandlerConstName = "typeScriptEventHandler";
        var handlerConstName = this.handlerName.charAt(0).toLowerCase() + this.handlerName.slice(1);
        var handler = project.findFile(handlerPath);
        handler.replace(srcDescription, this.description);
        handler.replace(srcHandlerName, this.handlerName);
        handler.replace(srcHandlerConstName, handlerConstName);
        handler.replace(srcPathExpression, this.pathExpression);
        var rootMatches = /^\/(\w+)\(\)/.exec(this.pathExpression);
        if (rootMatches == null || rootMatches.length < 2) {
            console.log("failed to match type of root node in path expression: " + this.pathExpression);
        }
        else {
            var newRoot = rootMatches[1];
            console.log("found root node: " + newRoot);
            var handlerContents = handler.content;
            var newHandlerContents = handlerContents.replace(/\bTag\b/g, newRoot);
            handler.setContent(newHandlerContents);
        }
        var testFile = project.findFile(testPath);
        testFile.replace(srcHandlerName, this.handlerName);
        var featureFile = project.findFile(featurePath);
        featureFile.replace(srcHandlerName, this.handlerName);
    };
    return AddTypeScriptEventHandler;
}());
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Name, { displayName: "Event Handler Name", description: "name of new event handler to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptEventHandler.prototype, "handlerName", void 0);
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Description, { displayName: "Handler Description", description: "short description of event handler to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptEventHandler.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Path Expression",
        description: "path expression to the event that will trigger this handler",
        pattern: "^/[\\s\\S]*$",
        validInput: "a valid path expression",
        minLength: 1,
        maxLength: 200,
        required: false
    }),
    __metadata("design:type", String)
], AddTypeScriptEventHandler.prototype, "pathExpression", void 0);
AddTypeScriptEventHandler = __decorate([
    Decorators_1.Editor("AddTypeScriptEventHandler", "adds a TypeScript Rug event handler to a Rug project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptEventHandler);
exports.AddTypeScriptEventHandler = AddTypeScriptEventHandler;
exports.addTypeScriptEventHandler = new AddTypeScriptEventHandler();
