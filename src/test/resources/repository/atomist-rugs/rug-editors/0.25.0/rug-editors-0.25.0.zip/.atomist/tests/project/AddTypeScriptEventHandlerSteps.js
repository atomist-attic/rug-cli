"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.Given("a manifest file", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.18.2,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.Given("an NPM package file", function (p) {
    p.addFile(".atomist/package.json", "{\n  \"dependencies\": {\n    \"@atomist/rug\": \"0.18.2\"\n  }\n}\n");
});
var handlerName = "MyNewHandler";
var description = "This handler rocks";
Core_1.When("AddTypeScriptEventHandler is run with default path expression", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEventHandler");
    psworld.editWith(editor, { handlerName: handlerName, description: description });
});
var pathExpression = "/Push()[/on::Repo()/channel::ChatChannel()][/contains::Commit()/author::GitHubId()[/hasGithubIdentity::Person()/hasChatIdentity::ChatId()]?]";
var newRootNode = "Push";
Core_1.When("AddTypeScriptEventHandler is run providing a path expression", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEventHandler");
    psworld.editWith(editor, {
        handlerName: handlerName,
        description: description,
        pathExpression: pathExpression
    });
});
var handlerPath = ".atomist/handlers/event/MyNewHandler.ts";
Core_1.Then("the event handler file exists", function (p, world) {
    return p.fileExists(handlerPath);
});
Core_1.Then("the event handler file contains the name", function (p, world) {
    return p.fileContains(handlerPath, "class " + handlerName);
});
Core_1.Then("the event handler file contains the description", function (p, world) {
    return p.fileContains(handlerPath, description);
});
Core_1.Then("the event handler file contains the default path expression", function (p, world) {
    return p.fileContains(handlerPath, "/Tag()");
});
Core_1.Then("the event handler file contains the provided path expression", function (p, world) {
    return p.fileContains(handlerPath, pathExpression);
});
Core_1.Then("the event handler file does not contain the original name", function (p, world) {
    return !p.fileContains(handlerPath, "TypeScriptEventHandler");
});
Core_1.Then("the event handler file does not contain the original description", function (p, world) {
    return !p.fileContains(handlerPath, "sample TypeScript event handler");
});
Core_1.Then("the event handler file does not contain the original path expression", function (p, world) {
    return !p.fileContains(handlerPath, "/Tag()");
});
var featurePath = ".atomist/tests/handlers/event/" + handlerName + "Test.feature";
Core_1.Then("the event handler test feature file should exist", function (p, world) {
    return p.fileExists(featurePath);
});
Core_1.Then("the event handler test feature file contains the name", function (p, world) {
    return p.fileContains(featurePath, handlerName);
});
Core_1.Then("the event handler test feature file does not contain the original name", function (p, world) {
    return !p.fileContains(featurePath, "TypeScriptEventHandler");
});
Core_1.Then("the event handler file does not contain the original intent", function (p, world) {
    return !p.fileContains(handlerPath, "run TypeScriptEventHandler");
});
var stepsPath = ".atomist/tests/handlers/event/" + handlerName + "Steps.ts";
Core_1.Then("the event handler test steps file should exist", function (p, world) {
    return p.fileExists(stepsPath);
});
Core_1.Then("the event handler test steps file contains the name", function (p, world) {
    return p.fileContains(stepsPath, handlerName);
});
Core_1.Then("the event handler test steps file does not contain the original name", function (p, world) {
    return !p.fileContains(stepsPath, "TypeScriptEventHandler");
});
Core_1.Then("the event handler file should import the proper node type", function (p, world) {
    return p.fileContains(handlerPath, "import { " + newRootNode + " } from \"@atomist/cortex/stub/" + newRootNode + "\";");
});
Core_1.Then("the event handler file should use the proper type parameters", function (p, world) {
    return p.fileContains(handlerPath, "implements HandleEvent<" + newRootNode + ", " + newRootNode + ">");
});
Core_1.Then("the event handler file should have the proper root node type", function (p, world) {
    return p.fileContains(handlerPath, "let root: " + newRootNode + " = event.root();");
});
Core_1.Then("the event handler file should not import the original root node", function (p, world) {
    return !p.fileContains(handlerPath, "import { Tag }");
});
Core_1.Then("the event handler file should not use the original type parameters", function (p, world) {
    return !p.fileContains(handlerPath, "HandleEvent<Tag, Tag>");
});
Core_1.Then("the event handler file should not have the original root node type", function (p, world) {
    return !p.fileContains(handlerPath, "let root: Tag = event.root();");
});
