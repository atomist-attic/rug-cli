"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("HavePathExpressionEngine rugNameisTypeScriptEditor for HavePathExpressionEngine puts a path expression in the typescript", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("HavePathExpressionEngine");
    var target = ".atomist/editors/TypeScriptEditor.ts";
    psworld.editWith(editor, { rugName: "TypeScriptEditor", target: ".atomist/editors/TypeScriptEditor.ts" });
});
Core_1.Then("fileContains target let eng PathExpressionEngine project context pathExpressionEngine for HavePathExpressionEngine puts a path expression in the typescript", function (p, world) {
    var target = ".atomist/editors/TypeScriptEditor.ts";
    return p.fileContains(target, "let eng: PathExpressionEngine = project.context().pathExpressionEngine();");
});
Core_1.Then("fileContains target import PathExpression PathExpressionEngine from atomist rug tree PathExpression for HavePathExpressionEngine puts a path expression in the typescript", function (p, world) {
    var target = ".atomist/editors/TypeScriptEditor.ts";
    return p.fileContains(target, "import { PathExpression, PathExpressionEngine } from '@atomist/rug/tree/PathExpression");
});
