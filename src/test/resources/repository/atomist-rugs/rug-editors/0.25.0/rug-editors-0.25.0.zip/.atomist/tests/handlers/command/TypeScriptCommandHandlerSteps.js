"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/handler/Core");
Core_1.Given("nothing", function (f) { });
Core_1.When("the TypeScriptCommandHandler is invoked", function (world) {
    var w = world;
    var handler = w.commandHandler("TypeScriptCommandHandler");
    w.invokeHandler(handler, {});
});
Core_1.Then("you get the right response", function (world) {
    var w = world;
    var expected = "Successfully ran TypeScriptCommandHandler: default value";
    var message = w.plan().messages[0].body;
    return message == expected;
});
