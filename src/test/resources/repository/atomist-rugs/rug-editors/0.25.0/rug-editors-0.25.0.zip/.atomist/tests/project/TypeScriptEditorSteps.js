"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("TypeScriptEditor inputParameteristhe inputParameter value for TypeScriptEditor is added to your project by AddTypeScriptEditor", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("TypeScriptEditor");
    psworld.editWith(editor, { inputParameter: "the inputParameter value" });
});
Core_1.Then("fileContains hello txt Hello Worldnot for TypeScriptEditor is added to your project by AddTypeScriptEditor", function (p, world) {
    return p.fileContains("hello.txt", "Hello, World!");
});
