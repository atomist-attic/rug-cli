"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var AddLocalEditor_1 = require("../../editors/AddLocalEditor");
var testEditorName = "TestEditorName";
var testEditorDescription = "this is just a test";
var testEditorGroup = "testing-group";
var testEditorPath = ".atomist/editors/" + testEditorName + ".ts";
Core_1.When("edit with AddLocalEditor using defaults", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddLocalEditor");
    psworld.editWith(editor, { editorName: testEditorName });
});
Core_1.When("edit with AddLocalEditor using description", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddLocalEditor");
    var params = {
        editorName: testEditorName,
        description: testEditorDescription,
        groupId: testEditorGroup
    };
    psworld.editWith(editor, params);
});
Core_1.Then("the new editor file should exist", function (p) {
    return p.fileExists(testEditorPath);
});
Core_1.Then("the new editor file should contain the editor name", function (p) {
    return p.fileContains(testEditorPath, "@Editor(\"" + testEditorName + "\"");
});
Core_1.Then("the new editor file should contain the default description", function (p) {
    return p.fileContains(testEditorPath, "\"" + AddLocalEditor_1.addLocalEditor.description + "\"");
});
Core_1.Then("the new editor file should contain the editor description", function (p) {
    return p.fileContains(testEditorPath, "\"" + testEditorDescription + "\"");
});
Core_1.Then("the new editor file should contain the editor class", function (p) {
    return p.fileContains(testEditorPath, "class " + testEditorName);
});
Core_1.Then("the new editor file should contain the editor instance", function (p) {
    return p.fileContains(testEditorPath, "new " + testEditorName + "()");
});
Core_1.Then("the new editor file should not contain the sample editor name", function (p) {
    return !p.fileContains(testEditorPath, "TypeScriptEditor");
});
Core_1.Then("the new editor file should not contain the sample editor description", function (p) {
    return !p.fileContains(testEditorPath, "sample TypeScript editor used by");
});
Core_1.Then("the new editor file should not contain the sample editor variable", function (p) {
    return !p.fileContains(testEditorPath, "typeScriptEditor");
});
Core_1.Then("the new editor feature file should exist", function (p) {
    return p.fileExists(".atomist/tests/project/" + testEditorName + "Test.feature");
});
Core_1.Then("the new editor test file should exist", function (p) {
    return p.fileExists(".atomist/tests/project/" + testEditorName + "Steps.ts");
});
Core_1.Then("the Atomist directory should exist", function (p) {
    return p.directoryExists(".atomist");
});
Core_1.Then("the manifest file should exist", function (p) {
    return p.fileExists(".atomist/manifest.yml");
});
Core_1.Then("the npm package file should exist", function (p) {
    return p.fileExists(".atomist/package.json");
});
Core_1.Then("the TypeScript typings should exist", function (p) {
    return p.directoryExists(".atomist/node_modules/@atomist/rug");
});
