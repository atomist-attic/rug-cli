"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var pName = "new-starter-project";
Core_1.When("NewStarterRugProject for NewStarterRugProjectTestProject", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewStarterRugProject");
    psworld.generateWith(generator, pName, {});
});
Core_1.Then("fileExists atomist manifest yml for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/manifest.yml");
});
Core_1.Then("fileContains atomist manifest yml 0 1 0 for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains(".atomist/manifest.yml", "0.1.0");
});
Core_1.Then("fileContains atomist manifest yml pName for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains(".atomist/manifest.yml", pName);
});
Core_1.Then("fileContains atomist manifest yml atomist rugs for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains(".atomist/manifest.yml", "atomist-rugs");
});
Core_1.Then("fileExists CHANGELOG md for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists("CHANGELOG.md");
});
Core_1.Then("fileContains CHANGELOG md 0 1 0 for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("CHANGELOG.md", "[0.1.0]");
});
Core_1.Then("fileContains CHANGELOG md All notable changes to this project will be documented in this file for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("CHANGELOG.md", "All notable changes to this project will be documented in this file.");
});
Core_1.Then("fileContains CHANGELOG md https github com atomist rugs pName compare 0 1 0 HEAD for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("CHANGELOG.md", "https://github.com/atomist-rugs/" + pName + "/compare/0.1.0...HEAD");
});
Core_1.Then("not result fileContains CHANGELOG md rug editors for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("CHANGELOG.md", "rug-editors");
});
Core_1.Then("not result fileContains CHANGELOG md 0 2 0 for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("CHANGELOG.md", "0.2.0");
});
Core_1.Then("not result fileContains CHANGELOG md NewRugProject for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("CHANGELOG.md", "NewRugProject");
});
Core_1.Then("fileExists CODE OF CONDUCT md for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists("CODE_OF_CONDUCT.md");
});
Core_1.Then("fileContains CODE OF CONDUCT md This Code of Conduct applies both within project spaces and in public spaces for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("CODE_OF_CONDUCT.md", "This Code of Conduct applies both within project spaces and in public spaces");
});
Core_1.Then("not result fileExists travis yml for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileExists(".travis.yml");
});
Core_1.Then("fileExists LICENSE for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists("LICENSE");
});
Core_1.Then("fileContains LICENSE APPENDIX How to apply the Apache License to your work for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("LICENSE", "APPENDIX: How to apply the Apache License to your work.");
});
Core_1.Then("fileExists README md for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists("README.md");
});
Core_1.Then("fileContains README md pName for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "# " + pName);
});
Core_1.Then("not result fileContains README md Atomist rug editors for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("README.md", "Atomist 'rug-editors'");
});
Core_1.Then("fileContains README md Atomist Rug archive project for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "Atomist Rug archive project");
});
Core_1.Then("not result fileContains README md editors to create a Rug archive project for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("README.md", "editors to create a Rug archive project");
});
Core_1.Then("not result fileContains README md AddTypeScript editor adds support files for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("README.md", "AddTypeScript editor adds support files");
});
Core_1.Then("fileContains README md https travis ci org atomist rugs pName svg branch master for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "https://travis-ci.org/atomist-rugs/" + pName + ".svg?branch=master");
});
Core_1.Then("fileContains README md not Slack Status https join atomist com badge svg https join atomist com for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "[![Slack Status](https://join.atomist.com/badge.svg)](https://join.atomist.com)");
});
Core_1.Then("not result fileContains README md NewRugProject for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("README.md", "### NewRugProject");
});
Core_1.Then("not result fileContains README md ruggery for NewStarterRugProjectTestProject", function (p, world) {
    return !p.fileContains("README.md", "ruggery");
});
Core_1.Then("fileContains README md rug http docs atomist com for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "[rug]: http://docs.atomist.com/");
});
Core_1.Then("fileContains README md Support for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "## Support");
});
Core_1.Then("fileContains README md Development for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "## Development");
});
Core_1.Then("fileContains README md Created by Atomist atomist for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "---\nCreated by [Atomist][atomist].");
});
Core_1.Then("fileContains README md Need Help Join our Slack team slack for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains("README.md", "Need Help?  [Join our Slack team][slack].");
});
Core_1.Then("fileExists atomist tsconfig json for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/tsconfig.json");
});
Core_1.Then("fileContains atomist tsconfig json experimentalDecorators true for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains(".atomist/tsconfig.json", '"experimentalDecorators": true');
});
Core_1.Then("fileExists atomist package json for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/package.json");
});
Core_1.Then("directoryExists atomist node modules atomist rug for NewStarterRugProjectTestProject", function (p, world) {
    return p.directoryExists(".atomist/node_modules/@atomist/rug");
});
Core_1.Then("fileExists atomist node modules atomist rug model Project ts for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/node_modules/@atomist/rug/model/Project.ts");
});
Core_1.Then("fileExists atomist editors MyFirstEditor ts for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/editors/MyFirstEditor.ts");
});
Core_1.Then("the starter editor contains the starter description", function (p, world) {
    return p.fileContains(".atomist/editors/MyFirstEditor.ts", '"sample Rug TypeScript editor"');
});
Core_1.Then("fileExists atomist tests project MyFirstEditorTest feature for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyFirstEditorTest.feature");
});
Core_1.Then("fileExists atomist tests project MyFirstEditorTest ts for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyFirstEditorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyFirstEditorTest ts MyFirstEditor for NewStarterRugProjectTestProject", function (p, world) {
    return p.fileContains(".atomist/tests/project/MyFirstEditorSteps.ts", "MyFirstEditor");
});
Core_1.Then("the starter command handler file exists", function (p) {
    return p.fileExists(".atomist/handlers/command/MyFirstCommandHandler.ts");
});
Core_1.Then("the starter event handler file exists", function (p) {
    return p.fileExists(".atomist/handlers/event/MyFirstEventHandler.ts");
});
