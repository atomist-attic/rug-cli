"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("ConvertExistingProjectToRugArchive for ConvertExistingProjectToRugArchive should add Rug archive files", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("ConvertExistingProjectToRugArchive");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1", manifest: ".atomist/manifest.yml" });
});
Core_1.Then("fileExists manifest for ConvertExistingProjectToRugArchive should add Rug archive files", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileExists(manifest);
});
Core_1.Then("fileContains manifest artifact archiveName for ConvertExistingProjectToRugArchive should add Rug archive files", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'artifact: "' + archiveName + '"');
});
Core_1.Then("fileContains manifest group groupId for ConvertExistingProjectToRugArchive should add Rug archive files", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, 'group: "' + groupId + '"');
});
Core_1.Then("fileContains manifest version for ConvertExistingProjectToRugArchive should add Rug archive files", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    return p.fileContains(manifest, version);
});
Core_1.When("ConvertExistingProjectToRugArchive archiveName is my-rug-archive, groupId is my-rug-group, version is 0.0.1 for ConvertExistingProjectToRugArchive should make no change if project already contains a manifest", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("ConvertExistingProjectToRugArchive");
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1" });
});
