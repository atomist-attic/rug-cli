"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var HavePathExpressionEngine = (function () {
    function HavePathExpressionEngine() {
    }
    HavePathExpressionEngine.prototype.edit = function (project) {
        var rugPath = ".atomist/editors/" + this.rugName + ".ts";
        var rug = project.findFile(rugPath);
        if (rug == null) {
            console.log("did not find " + rugPath);
            return;
        }
        console.log("Found file " + rug.path);
        if (!rug.contains("project.context().pathExpressionEngine()")) {
            rug.regexpReplace("(edit\\(.*\\) \\{)", "$1\n        let eng: PathExpressionEngine = project.context().pathExpressionEngine();\n");
        }
        if (!rug.contains("import { PathExpression, PathExpressionEngine } from '@atomist/rug/tree/PathExpression'")) {
            rug.prepend("import { PathExpression, PathExpressionEngine } from '@atomist/rug/tree/PathExpression'\n");
        }
    };
    return HavePathExpressionEngine;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Editor to Modify",
        description: "name of a TypeScript rug",
        pattern: RugOperation_1.Pattern.any,
        validInput: "an existing TypeScript rug in your repository",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], HavePathExpressionEngine.prototype, "rugName", void 0);
HavePathExpressionEngine = __decorate([
    Decorators_1.Editor("HavePathExpressionEngine", "adds access to path expression engine in a Rug editor"),
    Decorators_1.Tags("atomist", "rug")
], HavePathExpressionEngine);
exports.HavePathExpressionEngine = HavePathExpressionEngine;
exports.havePathExpressionEngine = new HavePathExpressionEngine();
