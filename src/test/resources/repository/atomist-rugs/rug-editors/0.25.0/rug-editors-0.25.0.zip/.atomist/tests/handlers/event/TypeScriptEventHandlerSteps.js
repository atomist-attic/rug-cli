"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/handler/Core");
var Tag_1 = require("@atomist/cortex/stub/Tag");
Core_1.Given("the TypeScriptEventHandler is registered", function (world) {
    var w = world;
    w.registerHandler("TypeScriptEventHandler");
});
var tagName = "1.2.3";
Core_1.When("a new Tag is received", function (world) {
    var w = world;
    var tag = new Tag_1.Tag().withName(tagName);
    w.sendEvent(tag);
});
Core_1.Then("the event handler should respond with the correct message", function (world) {
    var expected = "Tag event: " + tagName;
    var message = world.plan().messages[0].body;
    return message == expected;
});
