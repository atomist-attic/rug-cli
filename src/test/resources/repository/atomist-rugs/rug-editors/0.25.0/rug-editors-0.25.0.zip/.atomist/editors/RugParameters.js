"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
exports.RugParameters = {
    Name: {
        displayName: "Rug Name",
        description: "name of a Rug",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid Rug name starting with a capital letter and containing only alphanumeric characters, from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    },
    Description: {
        displayName: "Rug Description",
        description: "short description of a Rug",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    },
    GroupId: {
        displayName: "Rug Archive Group ID",
        description: "Maven group identifier, often used to provide a namespace for your rugs, e.g., company-rugs, typically the GitHub owner",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "a valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters",
        minLength: 1,
        maxLength: 100
    }
};
