"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("TypeScriptGenerator for TypeScriptGenerator should create a new project based on this archive", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("TypeScriptGenerator");
    psworld.generateWith(generator, "new-test-project", {});
});
Core_1.Then("fileExists README md for TypeScriptGenerator should create a new project based on this archive", function (p, world) {
    return p.fileExists("README.md");
});
