"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugGeneratorFunctions_1 = require("./RugGeneratorFunctions");
var NewRugProject = (function () {
    function NewRugProject() {
        this.version = "0.1.0";
    }
    NewRugProject.prototype.populate = function (project) {
        var toRemove = [
            "CHANGELOG.md",
            "CODE_OF_CONDUCT.md",
            "LICENSE"
        ];
        RugGeneratorFunctions_1.removeUnnecessaryFiles(project, toRemove);
        RugGeneratorFunctions_1.cleanReadMe(project, this.description, this.owner);
        var params = {
            archiveName: project.name,
            groupId: this.owner,
            version: this.version
        };
        project.editWith("AddManifestYml", params);
    };
    return NewRugProject;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Group ID",
        description: "Maven group identifier, often used to provide a namespace for your rugs, e.g., company-rugs, typically the GitHub owner",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "a valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], NewRugProject.prototype, "owner", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Description",
        description: "short descriptive text describing the new project",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], NewRugProject.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Version",
        description: "initial version of the project, e.g., 1.2.3",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "a valid semantic version, http://semver.org",
        minLength: 5,
        maxLength: 100,
        required: false
    }),
    __metadata("design:type", String)
], NewRugProject.prototype, "version", void 0);
NewRugProject = __decorate([
    Decorators_1.Generator("NewRugProject", "creates a minimal Rug archive project with metadata and no Rugs"),
    Decorators_1.Tags("rug", "atomist")
], NewRugProject);
exports.NewRugProject = NewRugProject;
exports.newRugProject = new NewRugProject();
