"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("AddTypeScriptEditor editorNameisMyNewEditor, descriptionisThe newest of the new for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEditor");
    psworld.editWith(editor, { editorName: "MyNewEditor", description: "The newest of the new" });
});
Core_1.Then("fileExists atomist editors MyNewEditor ts for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileExists(".atomist/editors/MyNewEditor.ts");
});
Core_1.Then("fileContains atomist editors MyNewEditor ts Editor MyNewEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", '@Editor("MyNewEditor"');
});
Core_1.Then("fileContains atomist editors MyNewEditor ts description for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    var description = "The newest of the new";
    return p.fileContains(".atomist/editors/MyNewEditor.ts", '"' + description + '"');
});
Core_1.Then("fileContains atomist editors MyNewEditor ts class MyNewEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", "class MyNewEditor");
});
Core_1.Then("fileContains atomist editors MyNewEditor ts new MyNewEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", "new MyNewEditor()");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts TypeScriptEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "TypeScriptEditor");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts sample TypeScript editor used by for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "sample TypeScript editor used by");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts helloTypeScript for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "helloTypeScript");
});
Core_1.Then("fileExists atomist tests project MyNewEditorTest ts for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyNewEditorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewEditorTest ts scenario MyNewEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains(".atomist/tests/project/MyNewEditorTest.feature", "Scenario: MyNewEditor");
});
Core_1.Then("not result fileContains atomist tests project MyNewEditorTest ts TypeScriptEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return !p.fileContains(".atomist/tests/project/MyNewEditorSteps.ts", "TypeScriptEditor");
});
Core_1.Then("fileExists README md for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileExists("README.md");
});
Core_1.Then("fileContains README md MyNewEditor for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", "### MyNewEditor");
});
Core_1.Then("fileContains README md The newest of the new for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", "The newest of the new");
});
Core_1.Then("fileContains README md Put your editor prerequisites here for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", "Put your editor prerequisites here.");
});
Core_1.Then("fileContains README md inputParameter Yes Example input parameter for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", "`inputParameter` | Yes | | Example input parameter");
});
Core_1.Then("fileContains README md MyNewEditor usage for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", ":MyNewEditor \\");
});
Core_1.Then("fileContains README md Explain what your editor does here for AddTypeScriptEditor should add a TypeScript editor to a Rug archive", function (p, world) {
    return p.fileContains("README.md", "Explain what your editor does here.");
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptEditor editorNameisMyNewEditor, descriptionisThe newest of the new for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEditor");
    psworld.editWith(editor, { editorName: "MyNewEditor", description: "The newest of the new" });
});
Core_1.Then("fileExists atomist editors MyNewEditor ts for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileExists(".atomist/editors/MyNewEditor.ts");
});
Core_1.Then("fileContains atomist editors MyNewEditor ts Editor MyNewEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", '@Editor("MyNewEditor"');
});
Core_1.Then("fileContains atomist editors MyNewEditor ts description for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    var description = "The newest of the new";
    return p.fileContains(".atomist/editors/MyNewEditor.ts", '"' + description + '"');
});
Core_1.Then("fileContains atomist editors MyNewEditor ts class MyNewEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", "class MyNewEditor");
});
Core_1.Then("fileContains atomist editors MyNewEditor ts new MyNewEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileContains(".atomist/editors/MyNewEditor.ts", "new MyNewEditor()");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts TypeScriptEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "TypeScriptEditor");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts sample TypeScript editor used by for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "sample TypeScript editor used by");
});
Core_1.Then("not result fileContains atomist editors MyNewEditor ts helloTypeScript for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return !p.fileContains(".atomist/editors/MyNewEditor.ts", "helloTypeScript");
});
Core_1.Then("fileExists atomist tests project MyNewEditorTest ts for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyNewEditorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewEditorTest ts scenario MyNewEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return p.fileContains(".atomist/tests/project/MyNewEditorTest.feature", "Scenario: MyNewEditor");
});
Core_1.Then("not result fileContains atomist tests project MyNewEditorTest ts TypeScriptEditor for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return !p.fileContains(".atomist/tests/project/MyNewEditorSteps.ts", "TypeScriptEditor");
});
Core_1.Then("not result fileExists README md for AddTypeScriptEditor should add a TypeScript editor even if no README", function (p, world) {
    return !p.fileExists("README.md");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptEditor should not make any changes if the target project is not a Rug archive", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptEditor editorNameisSillyPerson, descriptionisDance! for AddTypeScriptEditor should not make any changes if the target project is not a Rug archive", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEditor");
    psworld.editWith(editor, { editorName: "SillyPerson", description: "Dance!" });
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptEditor should make ready for typescript if not ready", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.When("AddTypeScriptEditor editorNameisSillyPerson, descriptionisDance! for AddTypeScriptEditor should make ready for typescript if not ready", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEditor");
    psworld.editWith(editor, { editorName: "SillyPerson", description: "Dance!" });
});
Core_1.Then("fileExists atomist editors SillyPerson ts for AddTypeScriptEditor should make ready for typescript if not ready", function (p, world) {
    return p.fileExists(".atomist/editors/SillyPerson.ts");
});
Core_1.Then("fileContains atomist editors SillyPerson ts Editor SillyPerson for AddTypeScriptEditor should make ready for typescript if not ready", function (p, world) {
    return p.fileContains(".atomist/editors/SillyPerson.ts", '@Editor("SillyPerson"');
});
Core_1.Then("fileExists atomist package json for AddTypeScriptEditor should make ready for typescript if not ready", function (p, world) {
    return p.fileExists(".atomist/package.json");
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptEditor should fail if no editor name provided", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptEditor should fail if no editor name provided", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptEditor descriptionisDance! for AddTypeScriptEditor should fail if no editor name provided", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptEditor");
    psworld.editWith(editor, { description: "Dance!" });
});
