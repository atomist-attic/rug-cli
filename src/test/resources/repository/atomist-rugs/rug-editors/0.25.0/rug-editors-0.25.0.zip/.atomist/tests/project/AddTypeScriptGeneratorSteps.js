"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("AddTypeScriptGenerator generatorName is MyNewGenerator, description is Description of MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptGenerator");
    psworld.editWith(editor, { generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Then("fileExists atomist editors MyNewGenerator ts for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileExists(".atomist/generators/MyNewGenerator.ts");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts Generator MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '@Generator("MyNewGenerator"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts description for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '"' + description + '"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts class MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "class MyNewGenerator");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts new MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "new MyNewGenerator()");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts TypeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "TypeScriptGenerator");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts sample TypeScript generator used by for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "sample TypeScript generator used by");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts typeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "typeScriptGenerator");
});
Core_1.Then("fileExists atomist tests project MyNewGeneratorTest ts for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyNewGeneratorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewGeneratorTest ts scenario MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains(".atomist/tests/project/MyNewGeneratorTest.feature", "Scenario: MyNewGenerator");
});
Core_1.Then("not result fileContains atomist tests project MyNewGeneratorTest ts TypeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return !p.fileContains(".atomist/tests/project/MyNewGeneratorSteps.ts", "TypeScriptGenerator");
});
Core_1.Then("fileExists README md for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileExists("README.md");
});
Core_1.Then("fileContains README md MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", "### MyNewGenerator");
});
Core_1.Then("fileContains README md Description of MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", "Description of MyNewGenerator");
});
Core_1.Then("fileContains README md This Rug has no prerequisites for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", "This Rug has no prerequisites.");
});
Core_1.Then("fileContains README md projectName Yes Name of project to be created for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", "`projectName` | Yes | | Name of project to be created");
});
Core_1.Then("fileContains README md MyNewGenerator example for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", ":MyNewGenerator \\");
});
Core_1.Then("fileContains README md Explain what your generator does here for AddTypeScriptGenerator should add a new TypeScript generator to an existing Rug Archive project", function (p, world) {
    return p.fileContains("README.md", "Explain what your generator does here.");
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptGenerator generatorName is MyNewGenerator, description is Description of MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptGenerator");
    psworld.editWith(editor, { generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Then("fileExists atomist editors MyNewGenerator ts for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileExists(".atomist/generators/MyNewGenerator.ts");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts Generator MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '@Generator("MyNewGenerator"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts description for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '"' + description + '"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts class MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "class MyNewGenerator");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts new MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "new MyNewGenerator()");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts TypeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "TypeScriptGenerator");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts sample TypeScript generator used by for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "sample TypeScript generator used by");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts typeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "typeScriptGenerator");
});
Core_1.Then("fileExists atomist tests project MyNewGeneratorTest ts for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileExists(".atomist/tests/project/MyNewGeneratorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewGeneratorTest ts scenario MyNewGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return p.fileContains(".atomist/tests/project/MyNewGeneratorTest.feature", "Scenario: MyNewGenerator");
});
Core_1.Then("not result fileContains atomist tests project MyNewGeneratorTest ts TypeScriptGenerator for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return !p.fileContains(".atomist/tests/project/MyNewGeneratorSteps.ts", "TypeScriptGenerator");
});
Core_1.Then("not result fileExists README md for AddTypeScriptGenerator should add a new TypeScript generator even if no README", function (p, world) {
    return !p.fileExists("README.md");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptGenerator should make no changes if no manifest.yml", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptGenerator generatorName is MyNewGenerator, description is Description of MyNewGenerator for AddTypeScriptGenerator should make no changes if no manifest.yml", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptGenerator");
    psworld.editWith(editor, { generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptGenerator should add package.json if not preset", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.When("AddTypeScriptGenerator generatorName is MyNewGenerator, description is Description of MyNewGenerator for AddTypeScriptGenerator should add package.json if not preset", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptGenerator");
    psworld.editWith(editor, { generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Then("fileExists atomist editors MyNewGenerator ts for AddTypeScriptGenerator should add package json if not preset", function (p, world) {
    return p.fileExists(".atomist/generators/MyNewGenerator.ts");
});
Core_1.Then("fileExists atomist package json for AddTypeScriptGenerator should add package json if not preset", function (p, world) {
    return p.fileExists(".atomist/package.json");
});
Core_1.Given("a file named .atomist/manifest.yml for AddTypeScriptGenerator should fail if no generator name provided", function (p) {
    p.addFile(".atomist/manifest.yml", "group: test-rugs\nartifact: test-manifest\nversion: \"0.1.0\"\nrequires: \"[0.12.0,1.0.0)\"\ndependencies:\nextensions:\n");
});
Core_1.Given("a file named .atomist/package.json for AddTypeScriptGenerator should fail if no generator name provided", function (p) { p.addFile(".atomist/package.json", "{\"dependencies\":{\"@atomist/rug\":\"0.12.0\"}}"); });
Core_1.When("AddTypeScriptGenerator descriptionisSomething wicked this way comes for AddTypeScriptGenerator should fail if no generator name provided", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptGenerator");
    psworld.editWith(editor, { description: "Something wicked this way comes" });
});
