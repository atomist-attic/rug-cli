"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugParameters_1 = require("./RugParameters");
var AddLocalEditor = (function () {
    function AddLocalEditor() {
        this.description = "an editor for modifying this project";
        this.groupId = "local";
    }
    AddLocalEditor.prototype.edit = function (project) {
        project.editWith("ConvertExistingProjectToRugArchive", { description: this.description, archiveName: project.name, groupId: this.groupId });
        project.editWith("AddTypeScript", {});
        if (!project.directoryExists(".atomist/node_modules")) {
        }
        project.editWith("AddTypeScriptEditor", this);
    };
    return AddLocalEditor;
}());
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Name, { name: "Editor Name", description: "name for the new Rug editor" })),
    __metadata("design:type", String)
], AddLocalEditor.prototype, "editorName", void 0);
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Description, { name: "Description", description: "description of the new Rug editor", required: false })),
    __metadata("design:type", String)
], AddLocalEditor.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter(RugParameters_1.RugParameters.GroupId),
    __metadata("design:type", String)
], AddLocalEditor.prototype, "groupId", void 0);
AddLocalEditor = __decorate([
    Decorators_1.Editor("AddLocalEditor", "adds an editor for modifying the local project, initiating a Rug archive if needed"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddLocalEditor);
exports.AddLocalEditor = AddLocalEditor;
exports.addLocalEditor = new AddLocalEditor();
