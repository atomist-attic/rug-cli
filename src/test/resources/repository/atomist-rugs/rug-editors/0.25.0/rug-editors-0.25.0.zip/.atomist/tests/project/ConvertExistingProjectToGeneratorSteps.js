"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.When("ConvertExistingProjectToGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("ConvertExistingProjectToGenerator");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1", manifest: ".atomist/manifest.yml", generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Then("fileExists manifest for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(manifest);
});
Core_1.Then("fileContains manifest artifact archiveName for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, 'artifact: "' + archiveName + '"');
});
Core_1.Then("fileContains manifest group groupId for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, 'group: "' + groupId + '"');
});
Core_1.Then("fileContains manifest version for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, version);
});
Core_1.Then("fileExists atomist tsconfig json for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/tsconfig.json");
});
Core_1.Then("fileContains atomist tsconfig json suppressImplicitAnyIndexErrors for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/tsconfig.json", "suppressImplicitAnyIndexErrors");
});
Core_1.Then("fileExists atomist gitignore for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/.gitignore");
});
Core_1.Then("fileContains atomist gitignore node modules for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/.gitignore", "node_modules");
});
Core_1.Then("not result directoryExists atomist node modules atomist rug for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.directoryExists(".atomist/node_modules/@atomist/rug");
});
Core_1.Then("not result fileExists atomist node modules atomist rug model Core ts for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileExists(".atomist/node_modules/@atomist/rug/model/Core.ts");
});
Core_1.Then("fileExists atomist editors MyNewGenerator ts for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/generators/MyNewGenerator.ts");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts Generator MyNewGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '@Generator("MyNewGenerator"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts class MyNewGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "class MyNewGenerator");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts new MyNewGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "new MyNewGenerator()");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts TypeScriptGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "TypeScriptGenerator");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts DESCRIPTION for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "@DESCRIPTION@");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts typeScriptGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "typeScriptGenerator");
});
Core_1.Then("fileExists atomist tests project MyNewGeneratorTest ts for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/tests/project/MyNewGeneratorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewGeneratorTest feature scenario MyNewGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/tests/project/MyNewGeneratorTest.feature", "Scenario: MyNewGenerator");
});
Core_1.Then("not result fileContains atomist tests project MyNewGeneratorTest ts TypeScriptGenerator for ConvertExistingProjectToGenerator should add Rug archive files and default generator", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/tests/project/MyNewGeneratorSteps.ts", "TypeScriptGenerator");
});
Core_1.Given("a file named README.md for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p) { p.addFile("README.md", "README.md\" = \"Beulah"); });
Core_1.Given("a file named CHANGELOG.md for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p) { p.addFile("CHANGELOG.md", "CHANGELOG.md\" = \"Handsome Western States"); });
Core_1.Given("a file named LICENSE for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p) { p.addFile("LICENSE", "LICENSE\" = \"When Your Heartstrings Break"); });
Core_1.Given("a file named configure for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p) { p.addFile("configure", "configure\" = \"The Coast Is Never Clear"); });
Core_1.When("ConvertExistingProjectToGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("ConvertExistingProjectToGenerator");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1", manifest: ".atomist/manifest.yml", generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
Core_1.Then("fileExists manifest for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(manifest);
});
Core_1.Then("fileContains manifest artifact archiveName for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, 'artifact: "' + archiveName + '"');
});
Core_1.Then("fileContains manifest group groupId for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, 'group: "' + groupId + '"');
});
Core_1.Then("fileContains manifest version for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(manifest, version);
});
Core_1.Then("fileExists atomist tsconfig json for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/tsconfig.json");
});
Core_1.Then("fileContains atomist tsconfig json suppressImplicitAnyIndexErrors for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/tsconfig.json", "suppressImplicitAnyIndexErrors");
});
Core_1.Then("fileExists atomist gitignore for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/.gitignore");
});
Core_1.Then("fileContains atomist gitignore node modules for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/.gitignore", "node_modules");
});
Core_1.Then("not result directoryExists atomist node modules atomist rug for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.directoryExists(".atomist/node_modules/@atomist/rug");
});
Core_1.Then("not result fileExists atomist node modules atomist rug model Core ts for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileExists(".atomist/node_modules/@atomist/rug/model/Core.ts");
});
Core_1.Then("fileExists atomist editors MyNewGenerator ts for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/generators/MyNewGenerator.ts");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts Generator MyNewGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", '@Generator("MyNewGenerator"');
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts class MyNewGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "class MyNewGenerator");
});
Core_1.Then("fileContains atomist editors MyNewGenerator ts new MyNewGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/generators/MyNewGenerator.ts", "new MyNewGenerator()");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts TypeScriptGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "TypeScriptGenerator");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts DESCRIPTION for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "@DESCRIPTION@");
});
Core_1.Then("not result fileContains atomist editors MyNewGenerator ts typeScriptGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/generators/MyNewGenerator.ts", "typeScriptGenerator");
});
Core_1.Then("fileExists atomist tests project MyNewGeneratorTest ts for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileExists(".atomist/tests/project/MyNewGeneratorSteps.ts");
});
Core_1.Then("fileContains atomist tests project MyNewGeneratorTest feature scenario MyNewGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/tests/project/MyNewGeneratorTest.feature", "Scenario: MyNewGenerator");
});
Core_1.Then("not result fileContains atomist tests project MyNewGeneratorTest ts TypeScriptGenerator for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return !p.fileContains(".atomist/tests/project/MyNewGeneratorSteps.ts", "TypeScriptGenerator");
});
Core_1.Then("fileContains atomist tests project MyNewGeneratorTest ts fileExists README md for ConvertExistingProjectToGenerator should add appropriate generator tests assertions", function (p, world) {
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var manifest = ".atomist/manifest.yml";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    return p.fileContains(".atomist/tests/project/MyNewGeneratorSteps.ts", 'fileExists("README.md")');
});
Core_1.When("ConvertExistingProjectToGenerator for ConvertExistingProjectToGenerator should make no change if project already contains a manifest", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("ConvertExistingProjectToGenerator");
    var archiveName = "my-rug-archive";
    var groupId = "my-rug-group";
    var version = "0.0.1";
    var generatorName = "MyNewGenerator";
    var description = "Description of MyNewGenerator";
    psworld.editWith(editor, { archiveName: "my-rug-archive", groupId: "my-rug-group", version: "0.0.1", generatorName: "MyNewGenerator", description: "Description of MyNewGenerator" });
});
