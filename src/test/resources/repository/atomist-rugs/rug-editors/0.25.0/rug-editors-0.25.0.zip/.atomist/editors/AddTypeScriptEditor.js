"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddFunctions_1 = require("./AddFunctions");
var RugParameters_1 = require("./RugParameters");
var AddTypeScriptEditor = (function () {
    function AddTypeScriptEditor() {
    }
    AddTypeScriptEditor.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            console.log("This project does not appear to be a Rug project");
            return;
        }
        project.editWith("AddTypeScript", {});
        var srcEditorName = "TypeScriptEditor";
        var srcEditorPath = ".atomist/editors/" + srcEditorName + ".ts";
        var srcTestPath = ".atomist/tests/project/" + srcEditorName + "Steps.ts";
        var srcFeaturePath = ".atomist/tests/project/" + srcEditorName + "Test.feature";
        var editorPath = srcEditorPath.replace(srcEditorName, this.editorName);
        var testPath = srcTestPath.replace(srcEditorName, this.editorName);
        var featurePath = srcFeaturePath.replace(srcEditorName, this.editorName);
        project.copyEditorBackingFileOrFailToDestination(srcEditorPath, editorPath);
        project.copyEditorBackingFileOrFailToDestination(srcTestPath, testPath);
        project.copyEditorBackingFileOrFailToDestination(srcFeaturePath, featurePath);
        var srcDescription = "sample TypeScript editor used by AddTypeScriptEditor";
        var srcEditorConstName = "typeScriptEditor";
        var editorConstName = this.editorName.charAt(0).toLowerCase() + this.editorName.slice(1);
        var editorFile = project.findFile(editorPath);
        editorFile.replace(srcDescription, this.description);
        editorFile.replace(srcEditorName, this.editorName);
        editorFile.replace(srcEditorConstName, editorConstName);
        var testFile = project.findFile(testPath);
        testFile.replace(srcEditorName, this.editorName);
        var featureFile = project.findFile(featurePath);
        featureFile.replace(srcDescription, this.description);
        featureFile.replace(srcEditorName, this.editorName);
        var example = "$ cd project/directory\n$ rug edit atomist-rugs:rug-editors:" + this.editorName + " \\\\\n    inputParameter='some value'";
        var exampleText = "Explain what your editor does here.";
        var prerequisites = "Put your editor prerequisites here.";
        var parameters = ["`inputParameter` | Yes | | Example input parameter"];
        var instructions = AddFunctions_1.readMeInstructions(this.editorName, this.description, example, exampleText, prerequisites, parameters);
        AddFunctions_1.addInstructionsToReadMe(project, instructions);
    };
    return AddTypeScriptEditor;
}());
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Name, { displayName: "Editor Name", description: "name of new editor to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptEditor.prototype, "editorName", void 0);
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Description, { displayName: "Editor Description", description: "short description of editor to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptEditor.prototype, "description", void 0);
AddTypeScriptEditor = __decorate([
    Decorators_1.Editor("AddTypeScriptEditor", "adds a TypeScript Rug editor to a Rug project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptEditor);
exports.AddTypeScriptEditor = AddTypeScriptEditor;
exports.addTypeScriptEditor = new AddTypeScriptEditor();
