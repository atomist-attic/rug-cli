"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddTypeScript = (function () {
    function AddTypeScript() {
    }
    AddTypeScript.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            console.log("This project does not appear to be a Rug archive project");
            return;
        }
        if (RugEditorsPredicates_1.IsSetUpForTypeScript(project)) {
            return;
        }
        project.copyEditorBackingFileOrFail(".atomist/package.json");
        project.copyEditorBackingFileOrFail(".atomist/tsconfig.json");
        project.copyEditorBackingFileOrFail(".atomist/.gitignore");
        console.log("TypeScript files added, run `cd .atomist && npm install`");
    };
    return AddTypeScript;
}());
AddTypeScript = __decorate([
    Decorators_1.Editor("AddTypeScript", "adds TypeScript supporting files to a Rug archive project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScript);
exports.AddTypeScript = AddTypeScript;
exports.addTypeScript = new AddTypeScript();
