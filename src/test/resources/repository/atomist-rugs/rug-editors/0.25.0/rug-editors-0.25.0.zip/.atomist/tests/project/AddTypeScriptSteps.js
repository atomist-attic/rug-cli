"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
Core_1.Given("a file named .atomist/manifest.yml", function (p) {
    p.addFile(".atomist/manifest.yml", "requires: \"0.12.0\"\n");
});
Core_1.When("edit with AddTypeScript", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScript");
    psworld.editWith(editor, {});
});
Core_1.Then("there should be a package file", function (p) {
    return p.fileExists(".atomist/package.json");
});
Core_1.Then("the package file depends on rug", function (p) {
    return p.fileContains(".atomist/package.json", '"@atomist/rugs"');
});
Core_1.Then("there should be a tsconfig file", function (p) {
    return p.fileExists(".atomist/tsconfig.json");
});
Core_1.Then("the tsconfig file should have standard contents", function (p) {
    return p.fileContains(".atomist/tsconfig.json", "suppressImplicitAnyIndexErrors");
});
Core_1.Then("there should be a gitignore file", function (p) {
    return p.fileExists(".atomist/.gitignore");
});
Core_1.Then("the gitignore file should ignore node modules", function (p) {
    return p.fileContains(".atomist/.gitignore", "node_modules");
});
Core_1.Then("the node modules directory should not exist", function (p) {
    return !p.directoryExists(".atomist/node_modules/@atomist/rug");
});
Core_1.Then("the rug interfaces should not exist", function (p) {
    return !p.fileExists(".atomist/node_modules/@atomist/rug/model/Core.ts");
});
