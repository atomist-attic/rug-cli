"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugGeneratorFunctions_1 = require("./RugGeneratorFunctions");
var NewStarterRugProject = (function () {
    function NewStarterRugProject() {
    }
    NewStarterRugProject.prototype.populate = function (project) {
        RugGeneratorFunctions_1.removeUnnecessaryFiles(project);
        var description = "Atomist Rug archive project";
        var owner = "atomist-rugs";
        RugGeneratorFunctions_1.cleanReadMe(project, description, owner);
        RugGeneratorFunctions_1.cleanChangeLog(project, owner);
        var version = "0.1.0";
        var manifestParams = {
            archiveName: project.name,
            groupId: owner,
            version: version
        };
        project.editWith("AddManifestYml", manifestParams);
        project.editWith("AddTypeScript", {});
        var editorParams = {
            editorName: "MyFirstEditor",
            description: "sample Rug TypeScript editor"
        };
        project.editWith("AddTypeScriptEditor", editorParams);
        var commandParams = {
            handlerName: "MyFirstCommandHandler",
            description: "sample Rug TypeScript command handler",
            intent: "run MyFirstCommandHandler"
        };
        project.editWith("AddTypeScriptCommandHandler", commandParams);
        var eventParams = {
            handlerName: "MyFirstEventHandler",
            description: "sample Rug TypeScript event handler"
        };
        project.editWith("AddTypeScriptEventHandler", eventParams);
    };
    return NewStarterRugProject;
}());
NewStarterRugProject = __decorate([
    Decorators_1.Generator("NewStarterRugProject", "creates a new Rug archive project using standard setup, sensible defaults, and starter Rugs"),
    Decorators_1.Tags("atomist", "rug", "starter")
], NewStarterRugProject);
exports.NewStarterRugProject = NewStarterRugProject;
exports.newStarterRugProject = new NewStarterRugProject();
