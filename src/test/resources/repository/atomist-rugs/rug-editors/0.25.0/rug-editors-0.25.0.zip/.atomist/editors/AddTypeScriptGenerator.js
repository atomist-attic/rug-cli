"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var AddFunctions_1 = require("./AddFunctions");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var RugParameters_1 = require("./RugParameters");
var AddTypeScriptGenerator = (function () {
    function AddTypeScriptGenerator() {
    }
    AddTypeScriptGenerator.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            console.log("This project does not appear to be a Rug archive project");
            return;
        }
        project.editWith("AddTypeScript", {});
        var srcGeneratorName = "TypeScriptGenerator";
        var srcGeneratorPath = ".atomist/generators/" + srcGeneratorName + ".ts";
        var srcTestPath = ".atomist/tests/project/TypeScriptGeneratorSteps.ts";
        var srcFeaturePath = ".atomist/tests/project/TypeScriptGeneratorTest.feature";
        var generatorPath = srcGeneratorPath.replace(srcGeneratorName, this.generatorName);
        var testPath = srcTestPath.replace(srcGeneratorName, this.generatorName);
        var featurePath = srcFeaturePath.replace(srcGeneratorName, this.generatorName);
        project.copyEditorBackingFileOrFailToDestination(srcGeneratorPath, generatorPath);
        project.copyEditorBackingFileOrFailToDestination(srcTestPath, testPath);
        project.copyEditorBackingFileOrFailToDestination(srcFeaturePath, featurePath);
        var srcDescription = "sample TypeScript generator used by AddTypeScriptGenerator";
        var srcGeneratorConstName = "typeScriptGenerator";
        var generatorConstName = this.generatorName[0].toLowerCase() + this.generatorName.slice(1);
        var generatorFile = project.findFile(generatorPath);
        generatorFile.replace(srcDescription, this.description);
        generatorFile.replace(srcGeneratorName, this.generatorName);
        generatorFile.replace(srcGeneratorConstName, generatorConstName);
        var testFile = project.findFile(testPath);
        testFile.replace(srcGeneratorName, this.generatorName);
        var featureFile = project.findFile(featurePath);
        featureFile.replace(srcDescription, this.description);
        featureFile.replace(srcGeneratorName, this.generatorName);
        var example = "$ cd parent/directory\n$ rug generate atomist-rugs:rug-editors:" + this.generatorName + " \\\\\n    my-new-project";
        var exampleText = "Explain what your generator does here.";
        var prerequisites = "Put your editor prerequisites here.";
        var parameters = ["`projectName` | Yes | | Name of project to be created"];
        var instructions = AddFunctions_1.readMeInstructions(this.generatorName, this.description, example, exampleText, "", parameters);
        AddFunctions_1.addInstructionsToReadMe(project, instructions);
    };
    return AddTypeScriptGenerator;
}());
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Name, { displayName: "Generator Name", description: "name of generator to add to Rug archive project" })),
    __metadata("design:type", String)
], AddTypeScriptGenerator.prototype, "generatorName", void 0);
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Description, { displayName: "Generator Description", description: "description of generator to add to Rug archive project" })),
    __metadata("design:type", String)
], AddTypeScriptGenerator.prototype, "description", void 0);
AddTypeScriptGenerator = __decorate([
    Decorators_1.Editor("AddTypeScriptGenerator", "adds a TypeScript generator to a Rug project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptGenerator);
exports.AddTypeScriptGenerator = AddTypeScriptGenerator;
exports.addTypeScriptGenerator = new AddTypeScriptGenerator();
