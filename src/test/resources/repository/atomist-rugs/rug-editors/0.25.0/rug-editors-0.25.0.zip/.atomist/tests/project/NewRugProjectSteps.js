"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var pName = "new-test-project";
Core_1.When("NewRugProject for NewRugProjectSetParameters", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewRugProject");
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    psworld.generateWith(generator, pName, { owner: "my.rugs", version: "0.0.1", description: "this is a test of the emergency broadcast system" });
});
Core_1.Then("fileExists atomist manifest yml for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileExists(".atomist/manifest.yml");
});
Core_1.Then("fileContains atomist manifest yml version for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", version);
});
Core_1.Then("fileContains atomist manifest yml pName for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", pName);
});
Core_1.Then("fileContains atomist manifest yml owner for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", owner);
});
Core_1.Then("not result fileExists CHANGELOG md for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileExists("CHANGELOG.md");
});
Core_1.Then("not result fileExists CODE OF CONDUCT md for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileExists("CODE_OF_CONDUCT.md");
});
Core_1.Then("not result fileExists travis yml for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileExists(".travis.yml");
});
Core_1.Then("fileExists README md for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileExists("README.md");
});
Core_1.Then("fileContains README md pName for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "# " + pName);
});
Core_1.Then("not result fileContains README md Atomist rug editors for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileContains("README.md", "Atomist 'rug-editors'");
});
Core_1.Then("fileContains README md description for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", description);
});
Core_1.Then("not result fileContains README md editors to create a Rug archive project for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileContains("README.md", "editors to create a Rug archive project");
});
Core_1.Then("not result fileContains README md AddTypeScript editor adds support files for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileContains("README.md", "AddTypeScript editor adds support files");
});
Core_1.Then("fileContains README md https travis ci org owner pName svg branch master for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "https://travis-ci.org/" + owner + "/" + pName + ".svg?branch=master");
});
Core_1.Then("fileContains README md not Slack Status https join atomist com badge svg https join atomist com for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "[![Slack Status](https://join.atomist.com/badge.svg)](https://join.atomist.com)");
});
Core_1.Then("not result fileContains README md NewRugProject for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileContains("README.md", "### NewRugProject");
});
Core_1.Then("not result fileContains README md ruggery for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return !p.fileContains("README.md", "ruggery");
});
Core_1.Then("fileContains README md rug http docs atomist com for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "[rug]: http://docs.atomist.com/");
});
Core_1.Then("fileContains README md Support for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "## Support");
});
Core_1.Then("fileContains README md Development for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "## Development");
});
Core_1.Then("fileContains README md Created by Atomist atomist for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "---\nCreated by [Atomist][atomist].");
});
Core_1.Then("fileContains README md Need Help Join our Slack team slack for NewRugProjectSetParameters", function (p, world) {
    var owner = "my.rugs";
    var version = "0.0.1";
    var description = "this is a test of the emergency broadcast system";
    return p.fileContains("README.md", "Need Help?  [Join our Slack team][slack].");
});
Core_1.When("NewRugProject for NewRugProjectDefaultParameters", function (p, world) {
    var psworld = world;
    var generator = psworld.generator("NewRugProject");
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    psworld.generateWith(generator, pName, { owner: "my-rugs", description: "this is not a test of the emergency broadcast system" });
});
Core_1.Then("fileExists atomist manifest yml for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileExists(".atomist/manifest.yml");
});
Core_1.Then("fileContains atomist manifest yml 0 1 0 for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", "0.1.0");
});
Core_1.Then("fileContains atomist manifest yml pName for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", pName);
});
Core_1.Then("fileContains atomist manifest yml owner for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains(".atomist/manifest.yml", owner);
});
Core_1.Then("not result fileExists CHANGELOG md for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileExists("CHANGELOG.md");
});
Core_1.Then("not result fileExists CODE OF CONDUCT md for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileExists("CODE_OF_CONDUCT.md");
});
Core_1.Then("not result fileExists travis yml for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileExists(".travis.yml");
});
Core_1.Then("fileExists README md for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileExists("README.md");
});
Core_1.Then("fileContains README md pName for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "# " + pName);
});
Core_1.Then("not result fileContains README md Atomist rug editors for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileContains("README.md", "Atomist 'rug-editors'");
});
Core_1.Then("fileContains README md description for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", description);
});
Core_1.Then("not result fileContains README md editors to create a Rug archive project for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileContains("README.md", "editors to create a Rug archive project");
});
Core_1.Then("not result fileContains README md AddTypeScript editor adds support files for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileContains("README.md", "AddTypeScript editor adds support files");
});
Core_1.Then("fileContains README md https travis ci org owner pName svg branch master for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "https://travis-ci.org/" + owner + "/" + pName + ".svg?branch=master");
});
Core_1.Then("fileContains README md not Slack Status https join atomist com badge svg https join atomist com for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "[![Slack Status](https://join.atomist.com/badge.svg)](https://join.atomist.com)");
});
Core_1.Then("not result fileContains README md NewRugProject for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileContains("README.md", "### NewRugProject");
});
Core_1.Then("not result fileContains README md ruggery for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return !p.fileContains("README.md", "ruggery");
});
Core_1.Then("fileContains README md rug http docs atomist com for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "[rug]: http://docs.atomist.com/");
});
Core_1.Then("fileContains README md Support for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "## Support");
});
Core_1.Then("fileContains README md Development for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "## Development");
});
Core_1.Then("fileContains README md Created by Atomist atomist for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "---\nCreated by [Atomist][atomist].");
});
Core_1.Then("fileContains README md Need Help Join our Slack team slack for NewRugProjectDefaultParameters", function (p, world) {
    var owner = "my-rugs";
    var description = "this is not a test of the emergency broadcast system";
    return p.fileContains("README.md", "Need Help?  [Join our Slack team][slack].");
});
