"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function addInstructionsToReadMe(project, instructions) {
    var eng = project.context.pathExpressionEngine;
    eng.with(project, "/*[@name='README.md']", function (r) {
        if (r.containsMatch("\n## Rugs[\\S\\s]*\n## Support")) {
            r.regexpReplace("\n## Support", instructions + "\n## Support");
        }
    });
}
exports.addInstructionsToReadMe = addInstructionsToReadMe;
function readMeInstructions(name, description, example, exampleText, prerequisites, parameters) {
    var instructions = "\n### " + name + "\n\n";
    instructions += description + "\n\n";
    if (prerequisites != null && prerequisites != "") {
        instructions += "#### Prerequisites\n\n" + prerequisites + "\n\n";
    }
    else {
        instructions += "#### Prerequisites\n\nThis Rug has no prerequisites.\n\n";
    }
    if (parameters != null && parameters.length > 0) {
        instructions += "#### Parameters\n\nThis Rug takes following parameters.\n\n"
            + "Name | Required | Default | Description\n-----|----------|---------|------------\n"
            + parameters.join("\n") + "\n\n";
    }
    else {
        instructions += "#### Parameters\n\n This Rug has no parameters.\n\n";
    }
    instructions += "#### Running\n\nRun this Rug as follows:\n\n```\n"
        + example + "\n```\n\n" + exampleText + "\n";
    return instructions.replace(/\$/g, "\\$");
}
exports.readMeInstructions = readMeInstructions;
