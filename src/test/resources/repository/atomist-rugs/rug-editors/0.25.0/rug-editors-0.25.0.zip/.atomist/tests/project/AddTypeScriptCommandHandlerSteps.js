"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("@atomist/rug/test/project/Core");
var handlerName = "MyNewHandler";
var description = "This handler rocks";
var intent = "rock and roll";
Core_1.When("AddTypeScriptCommandHandler is run", function (p, world) {
    var psworld = world;
    var editor = psworld.editor("AddTypeScriptCommandHandler");
    psworld.editWith(editor, {
        handlerName: handlerName,
        description: description,
        intent: intent
    });
});
var handlerPath = ".atomist/handlers/command/" + handlerName + ".ts";
Core_1.Then("the command handler file exists", function (p, world) {
    return p.fileExists(handlerPath);
});
Core_1.Then("the command handler file contains the name", function (p, world) {
    return p.fileContains(handlerPath, "class " + handlerName);
});
Core_1.Then("the command handler file contains the description", function (p, world) {
    return p.fileContains(handlerPath, description);
});
Core_1.Then("the command handler file contains the intent", function (p, world) {
    return p.fileContains(handlerPath, "@Intent(\"" + intent + "\")");
});
Core_1.Then("the command handler file does not contain the original name", function (p, world) {
    return !p.fileContains(handlerPath, "TypeScriptCommandHandler");
});
Core_1.Then("the command handler file does not contain the original description", function (p, world) {
    return !p.fileContains(handlerPath, "sample TypeScript command handler");
});
Core_1.Then("the command handler file does not contain the original intent", function (p, world) {
    return !p.fileContains(handlerPath, "run TypeScriptCommandHandler");
});
var featurePath = ".atomist/tests/handlers/command/" + handlerName + "Test.feature";
Core_1.Then("the command handler test feature file should exist", function (p, world) {
    return p.fileExists(featurePath);
});
Core_1.Then("the command handler test feature file contains the name", function (p, world) {
    return p.fileContains(featurePath, handlerName);
});
Core_1.Then("the command handler test feature file does not contain the original name", function (p, world) {
    return !p.fileContains(featurePath, "TypeScriptCommandHandler");
});
Core_1.Then("the command handler file does not contain the original intent", function (p, world) {
    return !p.fileContains(handlerPath, "run TypeScriptCommandHandler");
});
var stepsPath = ".atomist/tests/handlers/command/" + handlerName + "Steps.ts";
Core_1.Then("the command handler test steps file should exist", function (p, world) {
    return p.fileExists(stepsPath);
});
Core_1.Then("the command handler test steps file contains the name", function (p, world) {
    return p.fileContains(stepsPath, handlerName);
});
Core_1.Then("the command handler test steps file does not contain the original name", function (p, world) {
    return !p.fileContains(stepsPath, "TypeScriptCommandHandler");
});
