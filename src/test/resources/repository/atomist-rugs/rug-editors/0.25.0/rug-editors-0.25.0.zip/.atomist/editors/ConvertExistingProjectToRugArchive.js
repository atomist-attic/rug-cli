"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugParameters_1 = require("./RugParameters");
var ConvertExistingProjectToRugArchive = (function () {
    function ConvertExistingProjectToRugArchive() {
        this.version = "0.1.0";
    }
    ConvertExistingProjectToRugArchive.prototype.edit = function (project) {
        project.editWith("AddManifestYml", this);
    };
    return ConvertExistingProjectToRugArchive;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Name",
        description: "name of your new Rug Archive, typically the same as the repo name",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "a valid GitHub repo name containing only alphanumeric, ., -, and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToRugArchive.prototype, "archiveName", void 0);
__decorate([
    Decorators_1.Parameter(RugParameters_1.RugParameters.GroupId),
    __metadata("design:type", String)
], ConvertExistingProjectToRugArchive.prototype, "groupId", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Version",
        description: "initial version of the project, e.g., 1.2.3",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "a valid semantic version, http://semver.org",
        minLength: 1,
        maxLength: 100,
        required: false,
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToRugArchive.prototype, "version", void 0);
ConvertExistingProjectToRugArchive = __decorate([
    Decorators_1.Editor("ConvertExistingProjectToRugArchive", "converts an existing project to a Rug archive project"),
    Decorators_1.Tags("rug", "atomist")
], ConvertExistingProjectToRugArchive);
exports.ConvertExistingProjectToRugArchive = ConvertExistingProjectToRugArchive;
exports.convertExistingProjectToRugArchive = new ConvertExistingProjectToRugArchive();
