"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var RugParameters_1 = require("./RugParameters");
var AddTypeScriptCommandHandler = (function () {
    function AddTypeScriptCommandHandler() {
    }
    AddTypeScriptCommandHandler.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            console.log("This project does not appear to be a Rug archive project");
            return;
        }
        project.editWith("AddTypeScript", {});
        var srcHandlerName = "TypeScriptCommandHandler";
        var srcHandlerPath = ".atomist/handlers/command/" + srcHandlerName + ".ts";
        var srcTestPath = ".atomist/tests/handlers/command/" + srcHandlerName + "Steps.ts";
        var srcFeaturePath = ".atomist/tests/handlers/command/" + srcHandlerName + "Test.feature";
        var handlerPath = srcHandlerPath.replace(srcHandlerName, this.handlerName);
        var testPath = srcTestPath.replace(srcHandlerName, this.handlerName);
        var featurePath = srcFeaturePath.replace(srcHandlerName, this.handlerName);
        project.copyEditorBackingFileOrFailToDestination(srcHandlerPath, handlerPath);
        project.copyEditorBackingFileOrFailToDestination(srcTestPath, testPath);
        project.copyEditorBackingFileOrFailToDestination(srcFeaturePath, featurePath);
        var srcDescription = "sample TypeScript command handler used by AddTypeScriptCommandHandler";
        var srcIntent = "run " + srcHandlerName;
        var srcHandlerConstName = "typeScriptCommandHandler";
        var handlerConstName = this.handlerName.charAt(0).toLowerCase() + this.handlerName.slice(1);
        var handler = project.findFile(handlerPath);
        handler.replace(srcDescription, this.description);
        handler.replace(srcIntent, this.intent);
        handler.replace(srcHandlerName, this.handlerName);
        handler.replace(srcHandlerConstName, handlerConstName);
        var testFile = project.findFile(testPath);
        testFile.replace(srcHandlerName, this.handlerName);
        var featureFile = project.findFile(featurePath);
        featureFile.replace(srcHandlerName, this.handlerName);
    };
    return AddTypeScriptCommandHandler;
}());
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Name, { displayName: "Event Handler Name", description: "name of new event handler to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptCommandHandler.prototype, "handlerName", void 0);
__decorate([
    Decorators_1.Parameter(__assign({}, RugParameters_1.RugParameters.Description, { displayName: "Handler Description", description: "short description of event handler to add to Rug project" })),
    __metadata("design:type", String)
], AddTypeScriptCommandHandler.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Bot Intent",
        description: "Message the bot will associate with this command",
        pattern: "^[A-Za-z][-\\w ]*$",
        validInput: "a phrase starting with a letter and containing only word characters and spaces",
        minLength: 1,
        maxLength: 200
    }),
    __metadata("design:type", String)
], AddTypeScriptCommandHandler.prototype, "intent", void 0);
AddTypeScriptCommandHandler = __decorate([
    Decorators_1.Editor("AddTypeScriptCommandHandler", "adds a TypeScript Rug event handler to a Rug project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptCommandHandler);
exports.AddTypeScriptCommandHandler = AddTypeScriptCommandHandler;
exports.addTypeScriptCommandHandler = new AddTypeScriptCommandHandler();
