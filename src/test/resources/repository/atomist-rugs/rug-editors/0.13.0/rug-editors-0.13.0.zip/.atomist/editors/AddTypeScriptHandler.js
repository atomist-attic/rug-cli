var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddTypeScriptHandler = (function () {
    function AddTypeScriptHandler() {
        this.path_expression = "/Tag()";
    }
    AddTypeScriptHandler.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project) || !RugEditorsPredicates_1.IsSetUpForTypeScript(project)) {
            return;
        }
        var handlerPath = ".atomist/handlers/" + this.handler_name + ".ts";
        var defaultHandlerName = "TypeScriptHandler";
        var defaultHandlerPath = ".atomist/handlers/" + defaultHandlerName + ".ts";
        var defaultPathExpression = "/Tag()";
        project.copyEditorBackingFileOrFail(defaultHandlerPath, handlerPath);
        var eng = project.context().pathExpressionEngine();
        var handlerPE = new PathExpression_1.PathExpression("/*[@name='.atomist']/handlers/*[@name='" + this.handler_name + ".ts']");
        var handler = eng.scalar(project, handlerPE);
        handler.replace(defaultPathExpression, this.path_expression);
    };
    return AddTypeScriptHandler;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Handler Name",
        description: "name of Rug handler to add",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid Rug Handler name starting with a capital letter and containing only alphanumberic characters from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptHandler.prototype, "handler_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Handler Description",
        description: "short descriptive text describing the new handler",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptHandler.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Path Expression",
        description: "path expression to the event in Atomist that will trigger this handler",
        pattern: "^/[\\s\\S]*$",
        validInput: "a valid path expression",
        minLength: 1,
        maxLength: 200
    }),
    __metadata("design:type", String)
], AddTypeScriptHandler.prototype, "path_expression", void 0);
AddTypeScriptHandler = __decorate([
    Decorators_1.Editor("AddTypeScriptHandler", "add TypeScript Rug handler to project"),
    Decorators_1.Tags("rug", "atomist")
], AddTypeScriptHandler);
exports.addTypeScriptHandler = new AddTypeScriptHandler();
//# sourceMappingURL=AddTypeScriptHandler.js.map