var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddFunctions_1 = require("./AddFunctions");
var AddTypeScriptEditor = (function () {
    function AddTypeScriptEditor() {
    }
    AddTypeScriptEditor.prototype.edit = function (project) {
        var _this = this;
        if (!RugEditorsPredicates_1.IsRugArchive(project) || !RugEditorsPredicates_1.IsSetUpForTypeScript(project)) {
            return;
        }
        var editorPath = ".atomist/editors/" + this.editor_name + ".ts";
        var testPath = ".atomist/tests/" + this.editor_name + ".rt";
        var defaultEditorName = "TypeScriptEditor";
        var defaultEditorPath = ".atomist/editors/" + defaultEditorName + ".ts";
        var defaultTestPath = ".atomist/tests/" + defaultEditorName + ".rt";
        project.copyEditorBackingFileOrFail(defaultEditorPath, editorPath);
        project.copyEditorBackingFileOrFail(defaultTestPath, testPath);
        var eng = project.context().pathExpressionEngine();
        var editorPE = "/*[@name='.atomist']/editors/*[@name='" + this.editor_name + ".ts']";
        eng.with(project, editorPE, function (e) {
            e.replace(defaultEditorName, _this.editor_name);
            e.replace("sample TypeScript editor used by AddTypeScriptEditor", _this.description);
            var defaultEditorConstName = "typeScriptEditor";
            var editorConstName = _this.editor_name.charAt(0).toLowerCase() + _this.editor_name.slice(1);
            e.replace(defaultEditorConstName, editorConstName);
        });
        var testPE = "/*[@name='.atomist']/tests/*[@name='" + this.editor_name + ".rt']";
        eng.with(project, testPE, function (t) {
            t.replace(defaultEditorName, _this.editor_name);
        });
        var example = "$ cd project/directory\n$ rug edit atomist-rugs:rug-editors:" + this.editor_name + " \\\\\n    input_parameter='some value'";
        var example_text = "Explain what your editor does here.";
        var prerequisites = "Put your editor prerequisites here.";
        var parameters = ["`input_parameter` | Yes | | Example input parameter"];
        var instructions = AddFunctions_1.readMeInstructions(this.editor_name, this.description, example, example_text, prerequisites, parameters);
        AddFunctions_1.addInstructionsToReadMe(project, instructions);
    };
    return AddTypeScriptEditor;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Editor Name",
        description: "name of new editor to add to Rug archive project",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid Rug Editor name starting with a capital letter and containing only alphanumeric characters from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptEditor.prototype, "editor_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Editor Description",
        description: "short description of editor to add to Rug archive project",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptEditor.prototype, "description", void 0);
AddTypeScriptEditor = __decorate([
    Decorators_1.Editor("AddTypeScriptEditor", "add TypeScript Rug editor to project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptEditor);
exports.addTypeScriptEditor = new AddTypeScriptEditor();
//# sourceMappingURL=AddTypeScriptEditor.js.map