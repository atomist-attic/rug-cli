var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddManifestYml = (function () {
    function AddManifestYml() {
        this.version = "0.1.0";
    }
    AddManifestYml.prototype.edit = function (project) {
        if (RugEditorsPredicates_1.IsRugArchive(project)) {
            return;
        }
        var manifestPath = ".atomist/manifest.yml";
        project.copyEditorBackingFileOrFail(manifestPath);
        var eng = project.context().pathExpressionEngine();
        var manifestPE = new PathExpression_1.PathExpression("/*[@name='.atomist']/*[@name='manifest.yml']");
        var manifest = eng.scalar(project, manifestPE);
        manifest.regexpReplace("(?m)^group:.*", 'group: "' + this.group_id + '"');
        manifest.regexpReplace("(?m)^artifact:.*", 'artifact: "' + this.archive_name + '"');
        manifest.regexpReplace("(?m)^version:.*", 'version: "' + this.version + '"');
        manifest.regexpReplace("(?m)^dependencies:\s*\n(\s*-.*\n)*", "dependencies:\n");
        manifest.regexpReplace("(?m)^extensions:\s*\n(\s*-.*\n)*", "extensions:\n");
        manifest.regexpReplace("(?m)^repo:.*\n", "");
        manifest.regexpReplace("(?m)^branch:.*\n", "");
        manifest.regexpReplace("(?m)^sha:.*\n", "");
        manifest.regexpReplace("(?m)^---\n", "");
        manifest.regexpReplace("(?m)^\n", "");
    };
    return AddManifestYml;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Name",
        description: "name of your new Rug Archive, typically the same as the repo name",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "a valid GitHub repo name containing only alphanumeric, ., -, and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddManifestYml.prototype, "archive_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Group ID",
        description: "Maven group identifier, often used to provide a namespace for your rugs, e.g., company-rugs, typically the GitHub owner",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "a valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddManifestYml.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Version",
        description: "initial version of the project, e.g., 1.2.3",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "a valid semantic version, http://semver.org",
        minLength: 1,
        maxLength: 100,
        required: false,
    }),
    __metadata("design:type", String)
], AddManifestYml.prototype, "version", void 0);
AddManifestYml = __decorate([
    Decorators_1.Editor("AddManifestYml", "add Rug archive manifest"),
    Decorators_1.Tags("rug", "atomist")
], AddManifestYml);
exports.addManifestYml = new AddManifestYml();
//# sourceMappingURL=AddManifestYml.js.map