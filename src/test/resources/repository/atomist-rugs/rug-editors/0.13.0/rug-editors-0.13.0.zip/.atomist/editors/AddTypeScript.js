var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var AddTypeScript = (function () {
    function AddTypeScript() {
    }
    AddTypeScript.prototype.edit = function (project) {
        if (!project.fileExists(".atomist/manifest.yml")) {
            return;
        }
        var packageJsonPath = ".atomist/package.json";
        var tsconfigJsonPath = ".atomist/tsconfig.json";
        var gitignorePath = ".atomist/.gitignore";
        var nodeModulesPath = ".atomist/node_modules";
        project.copyEditorBackingFileOrFail(packageJsonPath);
        project.copyEditorBackingFileOrFail(tsconfigJsonPath);
        project.copyEditorBackingFileOrFail(gitignorePath);
        project.copyEditorBackingFilesPreservingPath(nodeModulesPath);
    };
    return AddTypeScript;
}());
AddTypeScript = __decorate([
    Decorators_1.Editor("AddTypeScript", "adds TypeScript supporting files to a Rug archive project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScript);
exports.addTypeScript = new AddTypeScript();
//# sourceMappingURL=AddTypeScript.js.map