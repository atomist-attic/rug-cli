var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var UpdateRugVersion = (function () {
    function UpdateRugVersion() {
    }
    UpdateRugVersion.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project)) {
            return;
        }
        var eng = project.context().pathExpressionEngine();
        var manifestPE = new PathExpression_1.PathExpression("/*[@name='.atomist']/*[@name='manifest.yml']");
        var manifest = eng.scalar(project, manifestPE);
        manifest.regexpReplace('(?m)^\s*requires:.*$', 'requires: "' + this.manifest_version + '"');
        if (project.fileExists(".atomist/package.json")) {
            var pkgJsonPE = new PathExpression_1.PathExpression("/*[@name='.atomist']/*[@name='package.json']");
            var pkgJson = eng.scalar(project, pkgJsonPE);
            pkgJson.regexpReplace('"@atomist/rug"\\s*:\\s*"[^"]*"', '"@atomist/rug": "' + this.package_version + '"');
        }
    };
    return UpdateRugVersion;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Version for manifest.yml",
        description: "version of Rug dependency",
        pattern: RugOperation_1.Pattern.version_range,
        validInput: "a valid Rug version of the form M.N.P or a version range of the form [M.N.P,X.Y.Z) where a square bracket includes the adjacent version and a parenthesis excludes it",
        minLength: 5,
        maxLength: 100
    }),
    __metadata("design:type", String)
], UpdateRugVersion.prototype, "manifest_version", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Version for package.json",
        description: "version of Rug dependency",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a valid NPM dependency version, https://docs.npmjs.com/files/package.json#dependencies, representing valid Rug version(s)",
        minLength: 5,
        maxLength: 100
    }),
    __metadata("design:type", String)
], UpdateRugVersion.prototype, "package_version", void 0);
UpdateRugVersion = __decorate([
    Decorators_1.Editor("UpdateRugVersion", "update Rug archive Rug dependency version"),
    Decorators_1.Tags("rug", "atomist")
], UpdateRugVersion);
exports.updateRugVersion = new UpdateRugVersion();
//# sourceMappingURL=UpdateRugVersion.js.map