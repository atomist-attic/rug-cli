var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var TypeScriptGenerator = (function () {
    function TypeScriptGenerator() {
    }
    TypeScriptGenerator.prototype.populate = function (project) {
        project.deleteFile(".atomist.yml");
    };
    return TypeScriptGenerator;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Project Name",
        description: "name of project to be created",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "a valid GitHub project name consisting of alphanumeric, ., -, and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], TypeScriptGenerator.prototype, "project_name", void 0);
TypeScriptGenerator = __decorate([
    Decorators_1.Generator("TypeScriptGenerator", "sample TypeScript generator used by AddTypeScriptGenerator"),
    Decorators_1.Tags("documentation")
], TypeScriptGenerator);
exports.typeScriptGenerator = new TypeScriptGenerator();
//# sourceMappingURL=TypeScriptGenerator.js.map