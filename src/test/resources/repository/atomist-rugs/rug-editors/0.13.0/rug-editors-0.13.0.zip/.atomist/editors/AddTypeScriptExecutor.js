var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
var RugEditorsPredicates_1 = require("./RugEditorsPredicates");
var AddTypeScriptExecutor = (function () {
    function AddTypeScriptExecutor() {
    }
    AddTypeScriptExecutor.prototype.edit = function (project) {
        if (!RugEditorsPredicates_1.IsRugArchive(project) || !RugEditorsPredicates_1.IsSetUpForTypeScript(project)) {
            return;
        }
        var executorPath = ".atomist/executors/" + this.executor_name + ".ts";
        var defaultExecutorName = "TypeScriptExecutor";
        var defaultExecutorPath = ".atomist/executors/" + defaultExecutorName + ".ts";
        var defaultExecutorVarName = "typeScriptExecutor";
        var executorVarName = this.executor_name.charAt(0).toLowerCase() + this.executor_name.slice(1);
        var defaultBotIntent = 'tags: ["atomist/intent=do something"]';
        var fullBotIntent = 'tags: ["atomist/intent=' + this.bot_intent + '"]';
        var defaultDescription = 'description: "Sample TypeScript Executor"';
        var fullDescription = 'description: "' + this.description + '"';
        project.copyEditorBackingFileOrFail(defaultExecutorPath, executorPath);
        var eng = project.context().pathExpressionEngine();
        var executorPE = new PathExpression_1.PathExpression("/*[@name='.atomist']/executors/*[@name='" + this.executor_name + ".ts']");
        var executor = eng.scalar(project, executorPE);
        executor.replace(defaultExecutorName, this.executor_name);
        executor.replace(defaultExecutorVarName, executorVarName);
        executor.replace(defaultBotIntent, fullBotIntent);
        executor.replace(defaultDescription, fullDescription);
    };
    return AddTypeScriptExecutor;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Executor Name",
        description: "name of Rug executor to add",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid Rug Executor name starting with a capital letter and containing only alphanumberic characters from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptExecutor.prototype, "executor_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Executor Description",
        description: "short descriptive text describing the new executor",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptExecutor.prototype, "description", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Bot Intent",
        description: "the phrase that the bot will recognize as the command to run this executor",
        pattern: RugOperation_1.Pattern.any,
        validInput: "free text",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptExecutor.prototype, "bot_intent", void 0);
AddTypeScriptExecutor = __decorate([
    Decorators_1.Editor("AddTypeScriptExecutor", "add TypeScript Rug executor to project"),
    Decorators_1.Tags("rug", "atomist")
], AddTypeScriptExecutor);
exports.addTypeScriptExecutor = new AddTypeScriptExecutor();
//# sourceMappingURL=AddTypeScriptExecutor.js.map