var PathExpression_1 = require("@atomist/rug/tree/PathExpression");
function addAssertionsForAllFilesInProject(project, generatorName) {
    var originalTestAssertionsString = "then\n  fileExists \"README.md\"";
    var testAssertionsString = project.files().reduce(function (acc, file) {
        if (notACommonPeripheralArtifact(file)) {
            if (acc === "then") {
                acc += "\n  ";
            }
            else {
                acc += "\n    and ";
            }
            acc += "fileExists \"" + file.path() + "\"";
        }
        return acc;
    }, "then");
    var eng = project.context().pathExpressionEngine();
    var testPathExpression = new PathExpression_1.PathExpression("/*[@name='.atomist']/tests/*[@name='" + generatorName + ".rt']");
    var testFile = eng.scalar(project, testPathExpression);
    testFile.replace(originalTestAssertionsString, testAssertionsString);
}
exports.addAssertionsForAllFilesInProject = addAssertionsForAllFilesInProject;
function notACommonPeripheralArtifact(file) {
    return (file.path().search("node_modules") < 0) &&
        (file.path().search(".idea") < 0) &&
        (file.path().search("target") < 0) &&
        (file.path().search(".atomist") < 0);
}
//# sourceMappingURL=ProjectToGeneratorOperations.js.map