var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var ProjectToGeneratorOperations_1 = require("./ProjectToGeneratorOperations");
var ConvertExistingProjectToGenerator = (function () {
    function ConvertExistingProjectToGenerator() {
        this.version = "0.1.0";
    }
    ConvertExistingProjectToGenerator.prototype.edit = function (project) {
        if (project.fileExists(".atomist/manifest.yml")) {
            return;
        }
        project.editWith("ConvertExistingProjectToRugArchive", this);
        project.editWith("AddTypeScript", {});
        project.editWith("AddTypeScriptGenerator", this);
        ProjectToGeneratorOperations_1.addAssertionsForAllFilesInProject(project, this.generator_name);
    };
    return ConvertExistingProjectToGenerator;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Name",
        description: "name of your new Rug Archive, typically the same as the repo name",
        pattern: RugOperation_1.Pattern.project_name,
        validInput: "a valid GitHub repo name containing only alphanumeric, ., -, and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToGenerator.prototype, "archive_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Group ID",
        description: "Maven group identifier, often used to provide a namespace for your rugs, e.g., company-rugs, typically the GitHub owner",
        pattern: RugOperation_1.Pattern.group_id,
        validInput: "a valid Maven group ID, which starts with a letter, -, or _ and contains only alphanumeric, -, and _ characters and may having leading period separated identifiers starting with letters or underscores and containing only alphanumeric and _ characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToGenerator.prototype, "group_id", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Rug Archive Version",
        description: "initial version of the project, e.g., 1.2.3",
        pattern: RugOperation_1.Pattern.semantic_version,
        validInput: "a valid semantic version, http://semver.org",
        minLength: 1,
        maxLength: 100,
        required: false,
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToGenerator.prototype, "version", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Generator Name",
        description: "name of generator to add to Rug archive project",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid generator name starting with a capital letter and consisting of alphanumeric characters from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToGenerator.prototype, "generator_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Generator Description",
        description: "description of generator to add to Rug archive project",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a string between one and 100 characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], ConvertExistingProjectToGenerator.prototype, "description", void 0);
ConvertExistingProjectToGenerator = __decorate([
    Decorators_1.Editor("ConvertExistingProjectToGenerator", "convert existing project to a Rug archive with a basic Generator"),
    Decorators_1.Tags("rug", "atomist")
], ConvertExistingProjectToGenerator);
exports.convertExistingProjectToGenerator = new ConvertExistingProjectToGenerator();
//# sourceMappingURL=ConvertExistingProjectToGenerator.js.map