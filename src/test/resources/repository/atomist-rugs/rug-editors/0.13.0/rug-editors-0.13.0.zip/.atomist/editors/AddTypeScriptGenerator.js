var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Decorators_1 = require("@atomist/rug/operations/Decorators");
var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var AddFunctions_1 = require("./AddFunctions");
var AddTypeScriptGenerator = (function () {
    function AddTypeScriptGenerator() {
    }
    AddTypeScriptGenerator.prototype.edit = function (project) {
        var _this = this;
        if (!project.fileExists(".atomist/manifest.yml")) {
            console.log("This project does not appear to be a Rug archive project, see https://github.com/atomist-rugs/rug-archive#addbasicrugarchivemanifestyml");
            return;
        }
        if (!project.fileExists(".atomist/package.json")) {
            console.log("This project does not appear to configured for TypeScript, see https://github.com/atomist-rugs/rug-editors#addtypescript");
            return;
        }
        var srcGeneratorPath = ".atomist/editors/TypeScriptGenerator.ts";
        var srcTestPath = ".atomist/tests/TypeScriptGenerator.rt";
        var generatorPath = srcGeneratorPath.replace("TypeScriptGenerator", this.generator_name);
        var testPath = srcTestPath.replace("TypeScriptGenerator", this.generator_name);
        project.copyEditorBackingFileOrFail(srcGeneratorPath, generatorPath);
        project.copyEditorBackingFileOrFail(srcTestPath, testPath);
        var lcFirstGeneratorName = this.generator_name[0].toLowerCase() + this.generator_name.slice(1);
        var eng = project.context().pathExpressionEngine();
        var generatorPathExpression = "/*[@name='.atomist']/editors/*[@name='" + this.generator_name + ".ts']";
        eng.with(project, generatorPathExpression, function (g) {
            g.replace("TypeScriptGenerator", _this.generator_name);
            g.replace("sample TypeScript generator used by AddTypeScriptGenerator", _this.description);
            g.replace("typeScriptGenerator", lcFirstGeneratorName);
        });
        var testPathExpression = "/*[@name='.atomist']/tests/*[@name='" + this.generator_name + ".rt']";
        eng.with(project, testPathExpression, function (t) {
            t.replace("TypeScriptGenerator", _this.generator_name);
        });
        var example = "$ cd parent/directory\n$ rug generate atomist-rugs:rug-editors:" + this.generator_name + " \\\\\n    my-new-project";
        var example_text = "Explain what your generator does here.";
        var prerequisites = "Put your editor prerequisites here.";
        var parameters = ["`project_name` | Yes | | Name of project to be created"];
        var instructions = AddFunctions_1.readMeInstructions(this.generator_name, this.description, example, example_text, "", parameters);
        AddFunctions_1.addInstructionsToReadMe(project, instructions);
    };
    return AddTypeScriptGenerator;
}());
__decorate([
    Decorators_1.Parameter({
        displayName: "Generator Name",
        description: "name of generator to add to Rug archive project",
        pattern: "^[A-Z][A-Za-z0-9]*$",
        validInput: "a valid generator name starting with a capital letter and consisting of alphanumeric characters from one to 100 characters long",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptGenerator.prototype, "generator_name", void 0);
__decorate([
    Decorators_1.Parameter({
        displayName: "Generator Description",
        description: "description of generator to add to Rug archive project",
        pattern: RugOperation_1.Pattern.any,
        validInput: "a string between one and 100 characters",
        minLength: 1,
        maxLength: 100
    }),
    __metadata("design:type", String)
], AddTypeScriptGenerator.prototype, "description", void 0);
AddTypeScriptGenerator = __decorate([
    Decorators_1.Editor("AddTypeScriptGenerator", "adds a TypeScript generator to a Rug archive project"),
    Decorators_1.Tags("rug", "atomist", "typescript")
], AddTypeScriptGenerator);
exports.addTypeScriptGenerator = new AddTypeScriptGenerator();
//# sourceMappingURL=AddTypeScriptGenerator.js.map