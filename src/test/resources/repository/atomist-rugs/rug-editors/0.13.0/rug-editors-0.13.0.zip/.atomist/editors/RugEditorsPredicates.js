function IsRugArchive(p) {
    return p.fileExists(".atomist/manifest.yml");
}
exports.IsRugArchive = IsRugArchive;
function IsSetUpForTypeScript(p) {
    return p.fileExists(".atomist/package.json");
}
exports.IsSetUpForTypeScript = IsSetUpForTypeScript;
//# sourceMappingURL=RugEditorsPredicates.js.map