var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
var typeScriptExecutor = {
    description: "Sample TypeScript Executor",
    name: "TypeScriptExecutor",
    tags: ["atomist/intent=do something"],
    parameters: [],
    execute: function (services, p) {
        return new RugOperation_1.Result(RugOperation_1.Status.Success, "OK");
    }
};
//# sourceMappingURL=TypeScriptExecutor.js.map